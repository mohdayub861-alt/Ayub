package com.example.model

enum class VariableType(val label: String, val symbol: String, val description: String) {
    SCALE("Scale", "📏", "Continuous interval or ratio measurements"),
    NOMINAL("Nominal", "🏷️", "Discrete categorical values without order"),
    ORDINAL("Ordinal", "📊", "Ranked or ordered categorical levels");

    companion object {
        // Alias for compatibility
        val CONTINUOUS = SCALE
    }
}

data class DataColumn(
    val id: String,
    val name: String,
    val type: VariableType,
    val values: List<String>
) {
    fun getNumericValues(): List<Double?> {
        return values.map { it.trim().toDoubleOrNull() }
    }

    fun getValidDoubles(): List<Double> {
        return values.mapNotNull { it.trim().toDoubleOrNull() }
    }
}

data class Dataset(
    val id: String,
    val title: String,
    val description: String,
    val columns: List<DataColumn>
) {
    val rowCount: Int
        get() = columns.maxOfOrNull { it.values.size } ?: 0

    fun getColumn(name: String): DataColumn? = columns.find { it.name.equals(name, ignoreCase = true) }

    fun getColumnById(id: String): DataColumn? = columns.find { it.id == id }

    fun scaleColumns(): List<DataColumn> = columns.filter { it.type == VariableType.SCALE }

    // Alias for continuous
    fun continuousColumns(): List<DataColumn> = scaleColumns()

    fun categoricalColumns(): List<DataColumn> = columns.filter { it.type == VariableType.NOMINAL || it.type == VariableType.ORDINAL }

    fun nominalColumns(): List<DataColumn> = columns.filter { it.type == VariableType.NOMINAL }

    fun ordinalColumns(): List<DataColumn> = columns.filter { it.type == VariableType.ORDINAL }
}

object SampleDatasets {
    fun studentPerformance(): Dataset {
        val groups = listOf("Control", "Intervention", "Control", "Intervention", "Control", "Intervention", "Control", "Intervention", "Control", "Intervention", "Control", "Intervention", "Control", "Intervention", "Control", "Intervention", "Control", "Intervention", "Control", "Intervention")
        val exam = listOf(68.5, 84.0, 72.0, 89.5, 65.0, 91.0, 70.5, 86.0, 61.5, 88.0, 74.0, 93.5, 69.0, 85.0, 71.0, 89.0, 64.0, 87.5, 73.0, 92.0)
        val anxiety = listOf(45.0, 28.0, 42.0, 22.0, 48.0, 25.0, 40.0, 26.0, 52.0, 24.0, 39.0, 20.0, 44.0, 27.0, 41.0, 23.0, 49.0, 26.0, 38.0, 21.0)
        val studyHours = listOf(12.0, 24.0, 15.0, 28.0, 10.0, 30.0, 14.0, 26.0, 8.0, 27.0, 16.0, 32.0, 13.0, 25.0, 14.5, 29.0, 9.5, 26.5, 15.5, 31.0)
        val preTest = listOf(55.0, 58.0, 60.0, 56.0, 52.0, 61.0, 57.0, 59.0, 50.0, 58.5, 62.0, 60.0, 54.0, 57.0, 58.0, 59.5, 51.0, 58.0, 61.0, 62.0)
        val postTest = listOf(69.0, 85.0, 71.5, 90.0, 64.0, 92.5, 71.0, 87.0, 62.0, 89.0, 75.0, 94.0, 68.5, 86.0, 72.0, 90.5, 63.5, 88.0, 74.5, 93.0)
        val sleepHrs = listOf(7.2, 8.0, 6.8, 7.5, 6.0, 8.2, 7.0, 7.8, 5.5, 8.1, 7.4, 8.5, 6.9, 7.6, 7.1, 8.0, 5.8, 7.9, 7.3, 8.4)
        val performanceCat = listOf("Average", "High", "Average", "High", "Low", "High", "Average", "High", "Low", "High", "High", "High", "Average", "High", "Average", "High", "Low", "High", "Average", "High")

        return Dataset(
            id = "student_wellbeing",
            title = "Student Exam & Wellbeing",
            description = "N=20 students examining study hours, anxiety, tutoring group, and pre/post test gains.",
            columns = listOf(
                DataColumn("c1", "group", VariableType.NOMINAL, groups),
                DataColumn("c2", "exam_score", VariableType.SCALE, exam.map { it.toString() }),
                DataColumn("c3", "anxiety", VariableType.SCALE, anxiety.map { it.toString() }),
                DataColumn("c4", "study_hours", VariableType.SCALE, studyHours.map { it.toString() }),
                DataColumn("c5", "pre_test", VariableType.SCALE, preTest.map { it.toString() }),
                DataColumn("c6", "post_test", VariableType.SCALE, postTest.map { it.toString() }),
                DataColumn("c7", "sleep_hrs", VariableType.SCALE, sleepHrs.map { it.toString() }),
                DataColumn("c8", "grade_level", VariableType.ORDINAL, performanceCat)
            )
        )
    }

    fun psychometricScale(): Dataset {
        val q1 = listOf(4, 5, 4, 3, 5, 2, 4, 5, 3, 4, 5, 4, 3, 5, 4)
        val q2 = listOf(5, 5, 4, 4, 5, 2, 4, 4, 3, 5, 5, 4, 3, 4, 4)
        val q3 = listOf(4, 4, 5, 3, 4, 1, 3, 5, 3, 4, 4, 5, 2, 5, 4)
        val q4 = listOf(2, 1, 2, 4, 1, 5, 2, 1, 4, 2, 1, 2, 4, 1, 2)
        val q5 = listOf(2, 2, 1, 4, 2, 5, 3, 1, 4, 2, 1, 2, 5, 2, 1)
        val q6 = listOf(4, 5, 5, 4, 4, 3, 4, 5, 3, 4, 5, 4, 3, 5, 4)
        val traitLevel = listOf("Low", "High", "High", "Low", "High", "Low", "Mid", "High", "Low", "Mid", "High", "Mid", "Low", "High", "Mid")

        return Dataset(
            id = "psychometric_scale",
            title = "Big Five Psychometric Scale",
            description = "N=15 item responses across Extraversion, Neuroticism, and Openness for reliability and factor analysis.",
            columns = listOf(
                DataColumn("p1", "extravert_1", VariableType.SCALE, q1.map { it.toString() }),
                DataColumn("p2", "extravert_2", VariableType.SCALE, q2.map { it.toString() }),
                DataColumn("p3", "extravert_3", VariableType.SCALE, q3.map { it.toString() }),
                DataColumn("p4", "neurotic_1", VariableType.SCALE, q4.map { it.toString() }),
                DataColumn("p5", "neurotic_2", VariableType.SCALE, q5.map { it.toString() }),
                DataColumn("p6", "openness_1", VariableType.SCALE, q6.map { it.toString() }),
                DataColumn("p7", "trait_level", VariableType.ORDINAL, traitLevel)
            )
        )
    }

    fun clinicalTrial(): Dataset {
        val drugGroup = listOf("Drug_A", "Drug_A", "Drug_A", "Drug_A", "Drug_B", "Drug_B", "Drug_B", "Drug_B", "Placebo", "Placebo", "Placebo", "Placebo")
        val depressionBase = listOf(24.5, 26.0, 23.0, 25.5, 25.0, 24.0, 27.0, 26.5, 24.0, 25.0, 26.0, 23.5)
        val depressionPost = listOf(14.0, 15.5, 13.0, 16.0, 18.5, 17.0, 19.0, 18.0, 23.0, 24.5, 25.0, 22.5)
        val depressionFollowup = listOf(12.5, 14.0, 11.5, 15.0, 18.0, 16.5, 18.5, 17.5, 23.5, 25.0, 25.5, 23.0)
        val age = listOf(34, 42, 29, 51, 45, 38, 55, 48, 33, 41, 58, 36)
        val responseStatus = listOf("Remission", "Remission", "Remission", "Partial", "Partial", "Partial", "None", "Partial", "None", "None", "None", "None")

        return Dataset(
            id = "clinical_trial",
            title = "Clinical Pharmacotherapy Trial",
            description = "N=12 patients evaluating depression score reductions across Drug A, Drug B, and Placebo with baseline covariate and follow-up.",
            columns = listOf(
                DataColumn("cl1", "treatment", VariableType.NOMINAL, drugGroup),
                DataColumn("cl2", "baseline_score", VariableType.SCALE, depressionBase.map { it.toString() }),
                DataColumn("cl3", "endpoint_score", VariableType.SCALE, depressionPost.map { it.toString() }),
                DataColumn("cl4", "followup_score", VariableType.SCALE, depressionFollowup.map { it.toString() }),
                DataColumn("cl5", "patient_age", VariableType.SCALE, age.map { it.toString() }),
                DataColumn("cl6", "response_status", VariableType.ORDINAL, responseStatus)
            )
        )
    }
}
