package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.DataGrid
import com.example.ui.components.JamoviRibbon
import com.example.ui.components.JamoviTab
import com.example.ui.tabs.*
import com.example.ui.theme.JamoviTeal
import com.example.ui.theme.JamoviTealLight
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.JamoviViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: JamoviViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                JamoviApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JamoviApp(viewModel: JamoviViewModel) {
    val dataset by viewModel.dataset.collectAsStateWithLifecycle()
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("jamovi_main_scaffold"),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = MaterialTheme.shapes.small,
                            color = Color(0xFF0097A7),
                            modifier = Modifier.size(32.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Science,
                                    contentDescription = "Jamovi Logo",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "jamovi",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 19.sp,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = MaterialTheme.shapes.extraSmall,
                                    color = Color(0xFF00BCD4).copy(alpha = 0.25f),
                                    modifier = Modifier.padding(top = 2.dp)
                                ) {
                                    Text(
                                        text = "APA 7th",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFD4AF37), // Luxury gold
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Statistical Analysis Engine",
                                fontSize = 11.sp,
                                color = Color(0xFFD5E5DC)
                            )
                        }
                    }
                },
                actions = {},
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF143D2B),
                    titleContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Jamovi Ribbon Tabs
            JamoviRibbon(
                currentTab = currentTab,
                onTabSelected = { viewModel.selectTab(it) }
            )

            // Active Tab Content
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            ) {
                when (currentTab) {
                    JamoviTab.DATA -> {
                        DataGrid(
                            dataset = dataset,
                            onCellEdited = { col, row, valStr -> viewModel.updateCell(col, row, valStr) },
                            onAddRow = { viewModel.addRow() },
                            onAddColumn = { name, type -> viewModel.addColumn(name, type) },
                            onUpdateColumnType = { colIdx, type -> viewModel.updateColumnType(colIdx, type) },
                            onRenameColumn = { colIdx, name -> viewModel.renameColumn(colIdx, name) },
                            onDeleteColumn = { colIdx -> viewModel.deleteColumn(colIdx) },
                            onSelectSampleDataset = { key -> viewModel.loadSampleDataset(key) },
                            onDatasetImported = { imported -> viewModel.setDataset(imported) }
                        )
                    }
                    JamoviTab.DESCRIPTIVES -> {
                        DescriptivesTab(dataset = dataset)
                    }
                    JamoviTab.T_TESTS -> {
                        TTestsTab(dataset = dataset)
                    }
                    JamoviTab.ANOVA -> {
                        AnovaTab(dataset = dataset)
                    }
                    JamoviTab.NON_PARAMETRIC -> {
                        NonParametricTab(dataset = dataset)
                    }
                    JamoviTab.CORRELATION -> {
                        CorrelationTab(dataset = dataset)
                    }
                    JamoviTab.REGRESSION -> {
                        RegressionTab(dataset = dataset)
                    }
                    JamoviTab.RELIABILITY -> {
                        ReliabilityTab(dataset = dataset)
                    }
                    JamoviTab.FACTOR_ANALYSIS -> {
                        FactorAnalysisTab(dataset = dataset)
                    }
                    JamoviTab.MEDIATION_SEM -> {
                        MediationSemTab(dataset = dataset)
                    }
                    JamoviTab.POWER -> {
                        PowerTab(dataset = dataset)
                    }
                }
            }
        }
    }
}
