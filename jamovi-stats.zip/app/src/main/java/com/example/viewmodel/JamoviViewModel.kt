package com.example.viewmodel

import androidx.lifecycle.ViewModel
import com.example.model.DataColumn
import com.example.model.Dataset
import com.example.model.SampleDatasets
import com.example.model.VariableType
import com.example.stats.StatsMath
import com.example.ui.components.JamoviTab
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class JamoviViewModel : ViewModel() {

    private val _dataset = MutableStateFlow<Dataset>(SampleDatasets.studentPerformance())
    val dataset: StateFlow<Dataset> = _dataset.asStateFlow()

    private val _currentTab = MutableStateFlow(JamoviTab.DATA)
    val currentTab: StateFlow<JamoviTab> = _currentTab.asStateFlow()

    private val _showApkDialog = MutableStateFlow(false)
    val showApkDialog: StateFlow<Boolean> = _showApkDialog.asStateFlow()

    fun selectTab(tab: JamoviTab) {
        _currentTab.value = tab
    }

    fun setApkDialogVisible(visible: Boolean) {
        _showApkDialog.value = visible
    }

    fun setDataset(newDataset: Dataset) {
        _dataset.value = newDataset
    }

    fun loadSampleDataset(key: String) {
        val newDs = when (key.lowercase()) {
            "psychometric" -> SampleDatasets.psychometricScale()
            "clinical" -> SampleDatasets.clinicalTrial()
            else -> SampleDatasets.studentPerformance()
        }
        _dataset.value = newDs
    }

    fun updateCell(colIndex: Int, rowIndex: Int, newValue: String) {
        val currentDs = _dataset.value
        if (colIndex in currentDs.columns.indices) {
            val targetCol = currentDs.columns[colIndex]
            val mutableValues = targetCol.values.toMutableList()
            while (mutableValues.size <= rowIndex) {
                mutableValues.add("")
            }
            mutableValues[rowIndex] = newValue
            val updatedCol = targetCol.copy(values = mutableValues)
            val updatedCols = currentDs.columns.toMutableList()
            updatedCols[colIndex] = updatedCol
            _dataset.value = currentDs.copy(columns = updatedCols)
        }
    }

    fun updateColumnType(colIndex: Int, newType: VariableType) {
        val currentDs = _dataset.value
        if (colIndex in currentDs.columns.indices) {
            val updatedCols = currentDs.columns.toMutableList()
            updatedCols[colIndex] = updatedCols[colIndex].copy(type = newType)
            _dataset.value = currentDs.copy(columns = updatedCols)
        }
    }

    fun renameColumn(colIndex: Int, newName: String) {
        val currentDs = _dataset.value
        if (colIndex in currentDs.columns.indices && newName.isNotBlank()) {
            val updatedCols = currentDs.columns.toMutableList()
            updatedCols[colIndex] = updatedCols[colIndex].copy(name = newName.trim())
            _dataset.value = currentDs.copy(columns = updatedCols)
        }
    }

    fun deleteColumn(colIndex: Int) {
        val currentDs = _dataset.value
        if (colIndex in currentDs.columns.indices && currentDs.columns.size > 1) {
            val updatedCols = currentDs.columns.toMutableList()
            updatedCols.removeAt(colIndex)
            _dataset.value = currentDs.copy(columns = updatedCols)
        }
    }

    fun addRow() {
        val currentDs = _dataset.value
        val updatedCols = currentDs.columns.map { col ->
            val mutableValues = col.values.toMutableList()
            val defaultVal = if (col.type == VariableType.SCALE) "0.0" else "Level_1"
            mutableValues.add(defaultVal)
            col.copy(values = mutableValues)
        }
        _dataset.value = currentDs.copy(columns = updatedCols)
    }

    fun addColumn(name: String, type: VariableType) {
        val currentDs = _dataset.value
        val defaultVal = if (type == VariableType.SCALE) "50.0" else "Group_A"
        val values = List(currentDs.rowCount) { defaultVal }
        val newCol = DataColumn("col_${System.currentTimeMillis()}", name, type, values)
        _dataset.value = currentDs.copy(columns = currentDs.columns + newCol)
    }

    fun generateFullApaManuscript(): String {
        val ds = _dataset.value
        val continuous = ds.scaleColumns()
        val categorical = ds.categoricalColumns()

        return buildString {
            appendLine("================================================================================")
            appendLine("                   JAMOVI STATISTICAL REPORT (APA 7th EDITION)                  ")
            appendLine("================================================================================")
            appendLine("Project Dataset: ${ds.title}")
            appendLine("Sample Size: N = ${ds.rowCount} observations, ${ds.columns.size} variables.")
            appendLine("Measurement Types: Scale (📏), Nominal (🏷️), Ordinal (📊)")
            appendLine()

            // 1. Descriptives & Frequencies
            appendLine("--------------------------------------------------------------------------------")
            appendLine("1. DESCRIPTIVE STATISTICS & FREQUENCY DISTRIBUTIONS")
            appendLine("--------------------------------------------------------------------------------")
            appendLine("Table 1. Descriptive Statistics for Study Measures")
            appendLine("Variable\tN\tMean\tSD\tMin\tMax\tSkewness\tKurtosis\tW\tp")
            continuous.forEach { col ->
                val res = StatsMath.calculateDescriptives(col.getValidDoubles(), col.name)
                appendLine("${res.varName}\t${res.n}\t${StatsMath.formatNumber(res.mean)}\t${StatsMath.formatNumber(res.sd)}\t${StatsMath.formatNumber(res.min)}\t${StatsMath.formatNumber(res.max)}\t${StatsMath.formatNumber(res.skewness)}\t${StatsMath.formatNumber(res.kurtosis)}\t${StatsMath.formatNumber(res.shapiroW)}\t${StatsMath.formatPValue(res.shapiroP)}")
            }

            appendLine()
            appendLine("Table 1b. Frequency Tables for Selected Variables")
            ds.columns.take(4).forEach { col ->
                val freq = StatsMath.calculateFrequencyTable(col.values, col.name, col.type == VariableType.SCALE)
                appendLine("Variable: ${col.name} (${col.type.label}) [N = ${freq.totalN}]")
                appendLine("Level\tCount\tPercent\tCum %")
                freq.rows.forEach { f ->
                    appendLine("${f.level}\t${f.count}\t${StatsMath.formatNumber(f.percent)}%\t${StatsMath.formatNumber(f.cumPercent)}%")
                }
                appendLine()
            }

            // 2. Correlation
            if (continuous.size >= 2) {
                appendLine("--------------------------------------------------------------------------------")
                appendLine("2. BIVARIATE CORRELATIONS")
                appendLine("--------------------------------------------------------------------------------")
                appendLine("Table 5. Intercorrelation Matrix (Pearson's r)")
                val header = continuous.mapIndexed { idx, _ -> "${idx + 1}" }.joinToString("\t")
                appendLine("Variable\tM\tSD\t$header")
                continuous.forEachIndexed { i, colI ->
                    val valsI = colI.getValidDoubles()
                    val rLine = continuous.mapIndexed { j, colJ ->
                        if (j < i) {
                            val r = StatsMath.pearson(valsI, colJ.getValidDoubles()).r
                            StatsMath.formatNumber(r)
                        } else if (j == i) "—" else ""
                    }.joinToString("\t")
                    appendLine("${i + 1}. ${colI.name}\t${StatsMath.formatNumber(StatsMath.mean(valsI))}\t${StatsMath.formatNumber(StatsMath.sd(valsI))}\t$rLine")
                }
                appendLine()
            }

            // 3. Regression
            if (continuous.size >= 2) {
                appendLine("--------------------------------------------------------------------------------")
                appendLine("3. MULTIPLE LINEAR REGRESSION")
                appendLine("--------------------------------------------------------------------------------")
                val yCol = continuous[0]
                val xCols = continuous.drop(1).take(2)
                val reg = StatsMath.multipleRegression(xCols.map { it.getValidDoubles() }, yCol.getValidDoubles(), xCols.map { it.name })
                appendLine("Model Summary: R = ${StatsMath.formatNumber(reg.r)}, R² = ${StatsMath.formatNumber(reg.rSquared)}, F(${StatsMath.formatNumber(reg.df1, 0)}, ${StatsMath.formatNumber(reg.df2, 0)}) = ${StatsMath.formatNumber(reg.fStat)}, p ${StatsMath.formatPValue(reg.pModel)}")
                appendLine("Predictor\tB\tSE\tBeta\tt\tp")
                reg.coefficients.forEach { c ->
                    appendLine("${c.term}\t${StatsMath.formatNumber(c.b)}\t${StatsMath.formatNumber(c.se)}\t${StatsMath.formatNumber(c.beta)}\t${StatsMath.formatNumber(c.t)}\t${StatsMath.formatPValue(c.p)}")
                }
                appendLine()
            }

            appendLine("================================================================================")
        }
    }
}
