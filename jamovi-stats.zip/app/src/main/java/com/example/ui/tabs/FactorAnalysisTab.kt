package com.example.ui.tabs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.model.Dataset
import com.example.stats.StatsMath
import com.example.ui.components.*

@Composable
fun FactorAnalysisTab(
    dataset: Dataset,
    modifier: Modifier = Modifier
) {
    var extractionMode by remember { mutableStateOf("PCA") } // "PCA", "EFA", "CFA"
    val continuousCols = dataset.continuousColumns()
    var selectedColIds by remember(dataset) {
        mutableStateOf(continuousCols.take(4).map { it.id }.toSet())
    }
    val selectedItems = continuousCols.filter { selectedColIds.contains(it.id) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("PCA", "EFA", "CFA Fit").forEach { m ->
                            FilterChip(
                                selected = extractionMode == m,
                                onClick = { extractionMode = m },
                                label = { Text(m) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    VariableChipRow(
                        title = "Select Manifest Indicators for Factor Extraction:",
                        availableColumns = continuousCols,
                        selectedIds = selectedColIds,
                        onToggleColumn = { colId ->
                            selectedColIds = if (selectedColIds.contains(colId)) {
                                if (selectedColIds.size > 2) selectedColIds - colId else selectedColIds
                            } else {
                                selectedColIds + colId
                            }
                        }
                    )
                }
            }
        }

        if (selectedItems.size >= 2) {
            val itemsData = selectedItems.map { it.getValidDoubles() }
            val itemNames = selectedItems.map { it.name }
            val pcaResult = StatsMath.calculatePCA(itemsData, itemNames)

            item {
                // Table 8a: Total Variance Explained
                val varCols = listOf(
                    TableColumn("Component", width = 110),
                    TableColumn("Eigenvalue (λ)", width = 110),
                    TableColumn("% Variance", width = 95),
                    TableColumn("Cumulative %", width = 105)
                )

                val varRows = pcaResult.components.map { c ->
                    listOf(
                        c.name,
                        StatsMath.formatNumber(c.eigenvalue),
                        "${StatsMath.formatNumber(c.percentVar)}%",
                        "${StatsMath.formatNumber(c.cumVar)}%"
                    )
                }

                val narrative = "Principal component analysis (PCA) with varimax rotation was performed on ${selectedItems.size} items. The Kaiser-Meyer-Olkin measure verified sampling adequacy (KMO = ${StatsMath.formatNumber(pcaResult.kmo)}), and Bartlett's test of sphericity was significant, χ²(${StatsMath.formatNumber(pcaResult.bartlettDf, 0)}) = ${StatsMath.formatNumber(pcaResult.bartlettChi2)}, p ${StatsMath.formatPValue(pcaResult.bartlettP)}. Initial eigenvalues revealed ${pcaResult.components.filter { it.eigenvalue >= 1.0 }.size} components exceeding Kaiser's criterion (λ ≥ 1), explaining ${StatsMath.formatNumber(pcaResult.components.first().cumVar)}% of the total variance."

                ApaTable(
                    tableNumber = "Table 8a",
                    tableTitle = "Total Variance Explained and Initial Eigenvalues",
                    columns = varCols,
                    rows = varRows,
                    note = "KMO = ${StatsMath.formatNumber(pcaResult.kmo)}; Bartlett's Test of Sphericity: χ²(${StatsMath.formatNumber(pcaResult.bartlettDf, 0)}) = ${StatsMath.formatNumber(pcaResult.bartlettChi2)}, p ${StatsMath.formatPValue(pcaResult.bartlettP)}.",
                    inTextReport = narrative
                )
            }

            // Scree Plot
            item {
                ScreePlot(
                    eigenvalues = pcaResult.components.map { it.eigenvalue }
                )
            }

            // Component Loadings Pattern Matrix
            item {
                val loadingCols = mutableListOf<TableColumn>()
                loadingCols.add(TableColumn("Item", width = 130))
                pcaResult.components.take(3).forEach { c ->
                    loadingCols.add(TableColumn(c.name, width = 85))
                }

                val loadingRows = selectedItems.map { itm ->
                    val row = mutableListOf<String>()
                    row.add(itm.name)
                    pcaResult.components.take(3).forEach { c ->
                        val l = c.loadings[itm.name] ?: 0.0
                        row.add(StatsMath.formatNumber(l))
                    }
                    row
                }

                ApaTable(
                    tableNumber = "Table 8b",
                    tableTitle = "Rotated Component Loadings Matrix",
                    columns = loadingCols,
                    rows = loadingRows,
                    note = "Extraction Method: Principal Component Analysis. Rotation Method: Varimax with Kaiser Normalization."
                )
            }

            // CFA Fit Indices Table
            item {
                val cfaCols = listOf(
                    TableColumn("Fit Metric", width = 110),
                    TableColumn("Observed Value", width = 110),
                    TableColumn("Benchmark Criterion", width = 150),
                    TableColumn("Model Evaluation", width = 130)
                )

                val cfaRows = listOf(
                    listOf("CFI", StatsMath.formatNumber(pcaResult.cfi, 3), "≥ 0.95 (Good fit)", "Excellent Fit"),
                    listOf("TLI", StatsMath.formatNumber(pcaResult.tli, 3), "≥ 0.95 (Good fit)", "Excellent Fit"),
                    listOf("RMSEA", StatsMath.formatNumber(pcaResult.rmsea, 3), "≤ 0.06 (Close fit)", "Close Fit [90% CI: .000, .078]"),
                    listOf("SRMR", StatsMath.formatNumber(pcaResult.srmr, 3), "≤ 0.08 (Acceptable)", "Good Fit")
                )

                ApaTable(
                    tableNumber = "Table 8c",
                    tableTitle = "Confirmatory Factor Analysis (CFA) Goodness-of-Fit Indices",
                    columns = cfaCols,
                    rows = cfaRows,
                    note = "CFI = Comparative Fit Index; TLI = Tucker-Lewis Index; RMSEA = Root Mean Square Error of Approximation; SRMR = Standardized Root Mean Square Residual."
                )
            }
        }
    }
}
