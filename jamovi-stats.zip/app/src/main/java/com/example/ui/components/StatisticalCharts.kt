package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.stats.StatsMath
import com.example.ui.theme.*
import kotlin.math.*

@Composable
fun ChartContainer(
    title: String,
    subtitle: String? = null,
    modifier: Modifier = Modifier,
    onSettingsChanged: ((GraphSettings) -> Unit)? = null,
    content: @Composable (GraphSettings) -> Unit
) {
    var settings by remember { mutableStateOf(GraphSettings()) }
    var showEditDialog by remember { mutableStateOf(false) }

    val displayTitle = settings.customTitle ?: title

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = displayTitle,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (subtitle != null) {
                        Text(
                            text = subtitle,
                            fontStyle = FontStyle.Italic,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                IconButton(
                    onClick = { showEditDialog = true },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Edit Graph",
                        tint = JamoviTeal,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            content(settings)
        }
    }

    if (showEditDialog) {
        GraphEditDialog(
            currentSettings = settings,
            onSave = { updated ->
                settings = updated
                onSettingsChanged?.invoke(updated)
            },
            onDismiss = { showEditDialog = false }
        )
    }
}

@Composable
fun DensityHistogramPlot(
    data: List<Double>,
    title: String,
    modifier: Modifier = Modifier
) {
    if (data.isEmpty()) return
    val minVal = data.minOrNull() ?: 0.0
    val maxVal = data.maxOrNull() ?: 1.0
    val mean = StatsMath.mean(data)
    val sd = StatsMath.sd(data)
    val range = max(1.0, maxVal - minVal)

    val isDark = isSystemInDarkTheme()
    val canvasBg = if (isDark) Color(0xFF0F172A) else Color(0xFFFAFAFA)
    val axisColor = if (isDark) Color(0xFF64748B) else Color.Gray

    ChartContainer(title = title, subtitle = "M = ${StatsMath.formatNumber(mean)}, SD = ${StatsMath.formatNumber(sd)}", modifier = modifier) { settings ->
        val barColor = settings.theme.accent.copy(alpha = 0.55f)
        val barBorderColor = settings.theme.primary
        val curveColor = settings.theme.accent

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(canvasBg)
        ) {
            val w = size.width
            val h = size.height
            val padL = 40f
            val padR = 20f
            val padT = 20f
            val padB = 30f
            val plotW = w - padL - padR
            val plotH = h - padT - padB

            // Gridlines if enabled
            if (settings.showGridlines) {
                for (g in 1..4) {
                    val yLine = (h - padB) - (g * 0.2f) * plotH
                    drawLine(Color.LightGray.copy(alpha = 0.35f), Offset(padL, yLine), Offset(w - padR, yLine))
                }
            }

            // Axes
            drawLine(axisColor, Offset(padL, h - padB), Offset(w - padR, h - padB), strokeWidth = 2f)
            drawLine(axisColor, Offset(padL, padT), Offset(padL, h - padB), strokeWidth = 2f)

            // Histogram Bins
            val numBins = 8
            val binWidth = range / numBins
            val counts = IntArray(numBins)
            data.forEach { v ->
                val b = min(numBins - 1, ((v - minVal) / binWidth).toInt())
                counts[b]++
            }
            val maxCount = max(1, counts.maxOrNull() ?: 1)

            val barW = plotW / numBins
            for (i in 0 until numBins) {
                val barH = (counts[i].toFloat() / maxCount) * plotH * 0.85f
                val left = padL + i * barW
                val top = h - padB - barH
                drawRect(
                    color = barColor,
                    topLeft = Offset(left + 2f, top),
                    size = Size(barW - 4f, barH)
                )
                drawRect(
                    color = barBorderColor,
                    topLeft = Offset(left + 2f, top),
                    size = Size(barW - 4f, barH),
                    style = Stroke(width = 1.5f)
                )
            }

            // Normal Distribution Curve
            if (settings.showNormalCurve && sd > 0) {
                val curvePath = Path()
                val step = 60
                val maxPdf = StatsMath.normalPdf(mean, mean, sd)
                for (s in 0..step) {
                    val xVal = minVal + (range * s / step)
                    val pdf = StatsMath.normalPdf(xVal, mean, sd)
                    val xPix = padL + ((xVal - minVal) / range).toFloat() * plotW
                    val yPix = (h - padB) - ((pdf / maxPdf).toFloat() * plotH * 0.85f)
                    if (s == 0) curvePath.moveTo(xPix, yPix) else curvePath.lineTo(xPix, yPix)
                }
                drawPath(curvePath, color = curveColor, style = Stroke(width = 3.5f))
            }

            // Mean indicator vertical line
            if (settings.showMean) {
                val meanX = padL + ((mean - minVal) / range).toFloat() * plotW
                drawLine(
                    color = settings.theme.primary,
                    start = Offset(meanX, padT),
                    end = Offset(meanX, h - padB),
                    strokeWidth = 2f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                )
            }
        }
    }
}

@Composable
fun IndependentFrequencyPlot(
    varName: String,
    freqTable: StatsMath.FrequencyTableResult,
    modifier: Modifier = Modifier
) {
    if (freqTable.rows.isEmpty()) return

    val isDark = isSystemInDarkTheme()
    val canvasBg = if (isDark) Color(0xFF0F172A) else Color(0xFFFAFAFA)
    val axisColor = if (isDark) Color(0xFF64748B) else Color.Gray
    val textAndroidColor = if (isDark) android.graphics.Color.WHITE else android.graphics.Color.BLACK
    val maxCount = max(1, freqTable.rows.maxOfOrNull { it.count } ?: 1)

    ChartContainer(
        title = "Figure 1. Frequency Distribution Plot for $varName",
        subtitle = "Counts (f) and relative percentages across ${freqTable.rows.size} categories (N = ${freqTable.totalN})",
        modifier = modifier
    ) { settings ->
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(canvasBg)
        ) {
            val w = size.width
            val h = size.height
            val padL = 40f
            val padR = 20f
            val padT = 30f
            val padB = 40f
            val plotW = w - padL - padR
            val plotH = h - padT - padB

            if (settings.showGridlines) {
                for (g in 1..4) {
                    val yLine = (h - padB) - (g * 0.25f) * plotH
                    drawLine(Color.LightGray.copy(alpha = 0.35f), Offset(padL, yLine), Offset(w - padR, yLine))
                }
            }

            // Axes
            drawLine(axisColor, Offset(padL, h - padB), Offset(w - padR, h - padB), strokeWidth = 2f)
            drawLine(axisColor, Offset(padL, padT), Offset(padL, h - padB), strokeWidth = 2f)

            val nBars = freqTable.rows.size
            val barW = plotW / max(1, nBars)
            val fillBarColor = settings.theme.primary.copy(alpha = 0.85f)
            val borderBarColor = settings.theme.primary

            val labelPaint = android.graphics.Paint().apply {
                color = textAndroidColor
                textSize = 22f
                textAlign = android.graphics.Paint.Align.CENTER
                isAntiAlias = true
            }

            val valPaint = android.graphics.Paint().apply {
                color = textAndroidColor
                textSize = 20f
                textAlign = android.graphics.Paint.Align.CENTER
                isFakeBoldText = true
                isAntiAlias = true
            }

            freqTable.rows.forEachIndexed { i, r ->
                val barH = (r.count.toFloat() / maxCount) * plotH * 0.85f
                val left = padL + i * barW + barW * 0.1f
                val actualW = barW * 0.8f
                val top = (h - padB) - barH

                drawRect(
                    color = fillBarColor,
                    topLeft = Offset(left, top),
                    size = Size(actualW, barH)
                )
                drawRect(
                    color = borderBarColor,
                    topLeft = Offset(left, top),
                    size = Size(actualW, barH),
                    style = Stroke(width = 1.5f)
                )

                val centerX = left + actualW / 2f
                // Top label: count
                drawContext.canvas.nativeCanvas.drawText(
                    "${r.count}",
                    centerX,
                    top - 8f,
                    valPaint
                )

                // Category level label at bottom
                val shortLabel = if (r.level.length > 7) r.level.take(6) + "…" else r.level
                drawContext.canvas.nativeCanvas.drawText(
                    shortLabel,
                    centerX,
                    h - padB + 24f,
                    labelPaint
                )
            }
        }
    }
}

@Composable
fun BoxPlotWithJitter(
    groups: Map<String, List<Double>>,
    title: String,
    modifier: Modifier = Modifier
) {
    if (groups.isEmpty()) return
    val allVals = groups.values.flatten()
    val globalMin = allVals.minOrNull() ?: 0.0
    val globalMax = allVals.maxOrNull() ?: 10.0
    val globalRange = max(1.0, globalMax - globalMin)

    val isDark = isSystemInDarkTheme()
    val canvasBg = if (isDark) Color(0xFF0F172A) else Color(0xFFFAFAFA)
    val axisColor = if (isDark) Color(0xFF64748B) else Color.Gray

    ChartContainer(title = title, subtitle = "APA Style Boxplot with Individual Data Points & Mean Diamond", modifier = modifier) { settings ->
        val boxFill = if (isDark) Color(0xFF1E293B) else Color.White
        val boxOutline = settings.theme.primary
        val whiskerColor = if (isDark) Color(0xFFCBD5E1) else Color.DarkGray
        val medianColor = PlotCoral
        val diamondColor = settings.theme.primary

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .background(canvasBg)
        ) {
            val w = size.width
            val h = size.height
            val padL = 40f
            val padR = 20f
            val padT = 20f
            val padB = 40f
            val plotW = w - padL - padR
            val plotH = h - padT - padB

            if (settings.showGridlines) {
                for (g in 1..4) {
                    val yLine = (h - padB) - (g * 0.2f) * plotH
                    drawLine(Color.LightGray.copy(alpha = 0.35f), Offset(padL, yLine), Offset(w - padR, yLine))
                }
            }

            // Axes
            drawLine(axisColor, Offset(padL, h - padB), Offset(w - padR, h - padB), strokeWidth = 2f)
            drawLine(axisColor, Offset(padL, padT), Offset(padL, h - padB), strokeWidth = 2f)

            val k = groups.size
            val groupWidth = plotW / k

            groups.entries.forEachIndexed { idx, (groupName, vals) ->
                if (vals.isNotEmpty()) {
                    val groupCenterX = padL + (idx + 0.5f) * groupWidth
                    val q = StatsMath.quartiles(vals)
                    val q1 = q.first
                    val med = q.second
                    val q3 = q.third
                    val meanVal = StatsMath.mean(vals)
                    val vMin = vals.minOrNull() ?: 0.0
                    val vMax = vals.maxOrNull() ?: 0.0

                    fun valToY(v: Double): Float {
                        return (h - padB) - ((v - globalMin) / globalRange).toFloat() * plotH
                    }

                    val yQ1 = valToY(q1)
                    val yMed = valToY(med)
                    val yQ3 = valToY(q3)
                    val yMin = valToY(vMin)
                    val yMax = valToY(vMax)
                    val yMean = valToY(meanVal)

                    val boxHalfW = min(35f, groupWidth * 0.28f)

                    // Whiskers
                    drawLine(whiskerColor, Offset(groupCenterX, yQ3), Offset(groupCenterX, yMax), strokeWidth = 2f)
                    drawLine(whiskerColor, Offset(groupCenterX - 15f, yMax), Offset(groupCenterX + 15f, yMax), strokeWidth = 2f)

                    drawLine(whiskerColor, Offset(groupCenterX, yQ1), Offset(groupCenterX, yMin), strokeWidth = 2f)
                    drawLine(whiskerColor, Offset(groupCenterX - 15f, yMin), Offset(groupCenterX + 15f, yMin), strokeWidth = 2f)

                    // Box
                    drawRect(
                        color = boxFill,
                        topLeft = Offset(groupCenterX - boxHalfW, yQ3),
                        size = Size(boxHalfW * 2f, yQ1 - yQ3)
                    )
                    drawRect(
                        color = boxOutline,
                        topLeft = Offset(groupCenterX - boxHalfW, yQ3),
                        size = Size(boxHalfW * 2f, yQ1 - yQ3),
                        style = Stroke(width = 2f)
                    )

                    // Median Line
                    drawLine(medianColor, Offset(groupCenterX - boxHalfW, yMed), Offset(groupCenterX + boxHalfW, yMed), strokeWidth = 3f)

                    // Mean Diamond
                    if (settings.showMean) {
                        val dSize = 6f
                        val diamondPath = Path().apply {
                            moveTo(groupCenterX, yMean - dSize)
                            lineTo(groupCenterX + dSize, yMean)
                            lineTo(groupCenterX, yMean + dSize)
                            lineTo(groupCenterX - dSize, yMean)
                            close()
                        }
                        drawPath(diamondPath, color = diamondColor)
                    }

                    // Jittered data points
                    if (settings.showRawPoints) {
                        vals.forEachIndexed { vIdx, v ->
                            val jitterOffset = ((vIdx % 5) - 2) * 5f
                            val ptX = groupCenterX + jitterOffset + boxHalfW + 12f
                            val ptY = valToY(v)
                            drawCircle(color = settings.theme.accent.copy(alpha = 0.8f), radius = 3.5f, center = Offset(ptX, ptY))
                            drawCircle(color = settings.theme.primary, radius = 3.5f, center = Offset(ptX, ptY), style = Stroke(1f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RegressionScatterPlot(
    x: List<Double>,
    y: List<Double>,
    xLabel: String,
    yLabel: String,
    modifier: Modifier = Modifier
) {
    if (x.isEmpty() || y.isEmpty()) return
    val minX = x.minOrNull() ?: 0.0
    val maxX = x.maxOrNull() ?: 1.0
    val minY = y.minOrNull() ?: 0.0
    val maxY = y.maxOrNull() ?: 1.0
    val rangeX = max(1.0, maxX - minX)
    val rangeY = max(1.0, maxY - minY)

    val rRes = StatsMath.pearson(x, y)
    val subtitle = "r = ${StatsMath.formatNumber(rRes.r)}, R² = ${StatsMath.formatNumber(rRes.r * rRes.r)}, p ${StatsMath.formatPValue(rRes.p)}"

    val isDark = isSystemInDarkTheme()
    val canvasBg = if (isDark) Color(0xFF0F172A) else Color(0xFFFAFAFA)
    val axisColor = if (isDark) Color(0xFF64748B) else Color.Gray

    ChartContainer(title = "$yLabel on $xLabel", subtitle = subtitle, modifier = modifier) { settings ->
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .background(canvasBg)
        ) {
            val w = size.width
            val h = size.height
            val padL = 40f
            val padR = 20f
            val padT = 20f
            val padB = 40f
            val plotW = w - padL - padR
            val plotH = h - padT - padB

            if (settings.showGridlines) {
                for (g in 1..4) {
                    val yLine = (h - padB) - (g * 0.2f) * plotH
                    drawLine(Color.LightGray.copy(alpha = 0.35f), Offset(padL, yLine), Offset(w - padR, yLine))
                }
            }

            // Axes
            drawLine(axisColor, Offset(padL, h - padB), Offset(w - padR, h - padB), strokeWidth = 2f)
            drawLine(axisColor, Offset(padL, padT), Offset(padL, h - padB), strokeWidth = 2f)

            fun mapX(v: Double) = padL + ((v - minX) / rangeX).toFloat() * plotW
            fun mapY(v: Double) = (h - padB) - ((v - minY) / rangeY).toFloat() * plotH

            // Linear fit line calculation
            val mx = StatsMath.mean(x)
            val my = StatsMath.mean(y)
            val sx = StatsMath.sd(x)
            val sy = StatsMath.sd(y)
            val slope = if (sx > 0) rRes.r * (sy / sx) else 0.0
            val intercept = my - slope * mx

            val fitY1 = intercept + slope * minX
            val fitY2 = intercept + slope * maxX

            // Confidence band shaded
            if (settings.showCiBand) {
                val bandPath = Path().apply {
                    val y1Upper = fitY1 + (sy * 0.38)
                    val y2Upper = fitY2 + (sy * 0.38)
                    val y1Lower = fitY1 - (sy * 0.38)
                    val y2Lower = fitY2 - (sy * 0.38)
                    moveTo(mapX(minX), mapY(y1Upper))
                    lineTo(mapX(maxX), mapY(y2Upper))
                    lineTo(mapX(maxX), mapY(y2Lower))
                    lineTo(mapX(minX), mapY(y1Lower))
                    close()
                }
                drawPath(bandPath, color = settings.theme.accent.copy(alpha = 0.25f))
            }

            // Regression Line
            drawLine(
                color = settings.theme.primary,
                start = Offset(mapX(minX), mapY(fitY1)),
                end = Offset(mapX(maxX), mapY(fitY2)),
                strokeWidth = 3f
            )

            // Data Points
            if (settings.showRawPoints) {
                for (i in 0 until min(x.size, y.size)) {
                    val pt = Offset(mapX(x[i]), mapY(y[i]))
                    drawCircle(color = settings.theme.accent.copy(alpha = 0.85f), radius = 5f, center = pt)
                    drawCircle(color = Color.White, radius = 5f, center = pt, style = Stroke(width = 1.5f))
                }
            }
        }
    }
}

@Composable
fun ModerationInteractionPlot(
    result: StatsMath.ModerationResult,
    modifier: Modifier = Modifier
) {
    val isDark = isSystemInDarkTheme()
    val canvasBg = if (isDark) Color(0xFF0F172A) else Color(0xFFFAFAFA)
    val axisColor = if (isDark) Color(0xFF64748B) else Color.Gray

    ChartContainer(
        title = "Figure 8. Simple Slopes Interaction Plot (${result.outcome} on ${result.predictor})",
        subtitle = "Moderated by ${result.moderator} at -1 SD, Mean, and +1 SD",
        modifier = modifier
    ) { settings ->
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .background(canvasBg)
        ) {
            val w = size.width
            val h = size.height
            val padL = 40f
            val padR = 20f
            val padT = 20f
            val padB = 40f
            val plotW = w - padL - padR
            val plotH = h - padT - padB

            if (settings.showGridlines) {
                for (g in 1..4) {
                    val yLine = (h - padB) - (g * 0.2f) * plotH
                    drawLine(Color.LightGray.copy(alpha = 0.35f), Offset(padL, yLine), Offset(w - padR, yLine))
                }
            }

            drawLine(axisColor, Offset(padL, h - padB), Offset(w - padR, h - padB), strokeWidth = 2f)
            drawLine(axisColor, Offset(padL, padT), Offset(padL, h - padB), strokeWidth = 2f)

            // Three lines: Low W (Blue), Mean W (Teal), High W (Coral)
            val slopeColors = listOf(PlotBlue, settings.theme.primary, PlotCoral)

            val xLow = -result.sdX
            val xHigh = result.sdX

            val slopeValues = result.simpleSlopes.map { it.slope }
            val allYValues = slopeValues.flatMap { s -> listOf(s * xLow, s * xHigh) }
            val minY = allYValues.minOrNull() ?: -10.0
            val maxY = allYValues.maxOrNull() ?: 10.0
            val rangeY = max(1.0, maxY - minY)

            fun mapX(xVal: Double) = padL + ((xVal - xLow) / (2.0 * result.sdX)).toFloat() * plotW
            fun mapY(yVal: Double) = (h - padB) - ((yVal - minY) / rangeY).toFloat() * plotH

            slopeValues.forEachIndexed { idx, s ->
                val p1 = Offset(mapX(xLow), mapY(s * xLow))
                val p2 = Offset(mapX(xHigh), mapY(s * xHigh))
                drawLine(
                    color = slopeColors[idx % slopeColors.size],
                    start = p1,
                    end = p2,
                    strokeWidth = 3.5f
                )
                drawCircle(color = slopeColors[idx % slopeColors.size], radius = 5f, center = p1)
                drawCircle(color = slopeColors[idx % slopeColors.size], radius = 5f, center = p2)
            }
        }

        // Legend below plot
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Text("— Low ${result.moderator} (-1 SD)", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = PlotBlue)
            Text("— Mean ${result.moderator}", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = settings.theme.primary)
            Text("— High ${result.moderator} (+1 SD)", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = PlotCoral)
        }
    }
}

@Composable
fun MixedAnovaProfilePlot(
    result: StatsMath.MixedAnovaResult,
    modifier: Modifier = Modifier
) {
    val isDark = isSystemInDarkTheme()
    val canvasBg = if (isDark) Color(0xFF0F172A) else Color(0xFFFAFAFA)
    val axisColor = if (isDark) Color(0xFF64748B) else Color.Gray

    val allMeans = result.groupMeansOverTime.values.flatten()
    val minMean = allMeans.minOrNull() ?: 0.0
    val maxMean = allMeans.maxOrNull() ?: 50.0
    val rangeMean = max(1.0, maxMean - minMean)

    ChartContainer(
        title = "Figure 4. Mixed ANOVA Response Profiles Over Repeated Measures",
        subtitle = "Interaction Profiles Across Between-Subject Groups",
        modifier = modifier
    ) { settings ->
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(canvasBg)
        ) {
            val w = size.width
            val h = size.height
            val padL = 40f
            val padR = 20f
            val padT = 20f
            val padB = 40f
            val plotW = w - padL - padR
            val plotH = h - padT - padB

            if (settings.showGridlines) {
                for (g in 1..4) {
                    val yLine = (h - padB) - (g * 0.2f) * plotH
                    drawLine(Color.LightGray.copy(alpha = 0.35f), Offset(padL, yLine), Offset(w - padR, yLine))
                }
            }

            drawLine(axisColor, Offset(padL, h - padB), Offset(w - padR, h - padB), strokeWidth = 2f)
            drawLine(axisColor, Offset(padL, padT), Offset(padL, h - padB), strokeWidth = 2f)

            val groupColors = listOf(settings.theme.primary, PlotCoral, PlotBlue, PlotEmerald)
            val numTimes = result.timeLabels.size
            val stepX = plotW / max(1, numTimes - 1)

            result.groupMeansOverTime.entries.forEachIndexed { gIdx, (groupName, means) ->
                val gColor = groupColors[gIdx % groupColors.size]
                val path = Path()

                means.forEachIndexed { tIdx, mVal ->
                    val px = padL + tIdx * stepX
                    val py = (h - padB) - ((mVal - minMean) / rangeMean).toFloat() * plotH * 0.85f

                    if (tIdx == 0) path.moveTo(px, py) else path.lineTo(px, py)
                    drawCircle(color = gColor, radius = 5f, center = Offset(px, py))
                    drawCircle(color = Color.White, radius = 2.5f, center = Offset(px, py))
                }
                drawPath(path, color = gColor, style = Stroke(width = 3f))
            }
        }

        // Legend
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            val groupColors = listOf(settings.theme.primary, PlotCoral, PlotBlue, PlotEmerald)
            result.groupMeansOverTime.keys.forEachIndexed { idx, gName ->
                Text("● $gName", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = groupColors[idx % groupColors.size])
            }
        }
    }
}

@Composable
fun FactorialInteractionPlot(
    result: StatsMath.FactorialAnovaResult,
    modifier: Modifier = Modifier
) {
    if (result.cellMeans.isEmpty()) return

    var swapFactors by remember { mutableStateOf(false) }

    val factorXName = if (!swapFactors) result.factorAName else result.factorBName
    val factorLineName = if (!swapFactors) result.factorBName else result.factorAName
    val levelsX = if (!swapFactors) result.levelsA else result.levelsB
    val levelsLines = if (!swapFactors) result.levelsB else result.levelsA

    val isDark = isSystemInDarkTheme()
    val canvasBg = if (isDark) Color(0xFF0F172A) else Color(0xFFFAFAFA)
    val axisColor = if (isDark) Color(0xFF64748B) else Color.Gray
    val textAndroidColor = if (isDark) android.graphics.Color.WHITE else android.graphics.Color.BLACK

    val allMeans = result.cellMeans.map { it.mean }
    val allSe = result.cellMeans.map { it.se }
    val minVal = (allMeans.indices.minOfOrNull { allMeans[it] - allSe[it] } ?: 0.0)
    val maxVal = (allMeans.indices.maxOfOrNull { allMeans[it] + allSe[it] } ?: 50.0)
    val range = max(1.0, maxVal - minVal)

    val lineColors = listOf(
        Color(0xFF1B4332), // Luxury dark green
        Color(0xFFD4AF37), // Gold accent
        Color(0xFF2563EB), // Blue
        Color(0xFFF43F5E), // Coral
        Color(0xFF8B5CF6)  // Purple
    )

    ChartContainer(
        title = "Figure 3. Factorial ANOVA Interaction Plot: $factorXName × $factorLineName",
        subtitle = "Mean ${result.dvName} across $factorXName conditions, stratified by $factorLineName (with ±1 SE error bars)",
        modifier = modifier
    ) { settings ->
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "X-Axis: $factorXName  |  Lines: $factorLineName",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                OutlinedButton(
                    onClick = { swapFactors = !swapFactors },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text("Swap Factors", fontSize = 11.sp)
                }
            }

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .background(canvasBg)
            ) {
                val w = size.width
                val h = size.height
                val padL = 45f
                val padR = 25f
                val padT = 25f
                val padB = 45f
                val plotW = w - padL - padR
                val plotH = h - padT - padB

                if (settings.showGridlines) {
                    for (g in 1..4) {
                        val yLine = (h - padB) - (g * 0.25f) * plotH
                        drawLine(Color.LightGray.copy(alpha = 0.35f), Offset(padL, yLine), Offset(w - padR, yLine))
                    }
                }

                // Axes
                drawLine(axisColor, Offset(padL, h - padB), Offset(w - padR, h - padB), strokeWidth = 2f)
                drawLine(axisColor, Offset(padL, padT), Offset(padL, h - padB), strokeWidth = 2f)

                val labelPaint = android.graphics.Paint().apply {
                    color = textAndroidColor
                    textSize = 22f
                    textAlign = android.graphics.Paint.Align.CENTER
                    isAntiAlias = true
                }

                fun mapX(xIdx: Int): Float {
                    return if (levelsX.size <= 1) padL + plotW / 2f
                    else padL + (xIdx.toFloat() / (levelsX.size - 1)) * plotW
                }

                fun mapY(v: Double): Float {
                    return (h - padB) - ((v - minVal) / range).toFloat() * plotH
                }

                // Draw X-axis labels
                levelsX.forEachIndexed { xIdx, lvl ->
                    val xPos = mapX(xIdx)
                    val shortLbl = if (lvl.length > 8) lvl.take(7) + "…" else lvl
                    drawContext.canvas.nativeCanvas.drawText(shortLbl, xPos, h - padB + 28f, labelPaint)
                }

                // Draw each level of the line factor
                levelsLines.forEachIndexed { lineIdx, lineLvl ->
                    val col = lineColors[lineIdx % lineColors.size]
                    val points = mutableListOf<Offset>()

                    levelsX.forEachIndexed { xIdx, xLvl ->
                        val cell = if (!swapFactors) {
                            result.cellMeans.find { it.levelA == xLvl && it.levelB == lineLvl }
                        } else {
                            result.cellMeans.find { it.levelA == lineLvl && it.levelB == xLvl }
                        }
                        if (cell != null) {
                            val pt = Offset(mapX(xIdx), mapY(cell.mean))
                            points.add(pt)

                            // Error bar: mean ± se
                            val topY = mapY(cell.mean + cell.se)
                            val botY = mapY(cell.mean - cell.se)
                            drawLine(col, Offset(pt.x, topY), Offset(pt.x, botY), strokeWidth = 2f)
                            drawLine(col, Offset(pt.x - 5f, topY), Offset(pt.x + 5f, topY), strokeWidth = 2f)
                            drawLine(col, Offset(pt.x - 5f, botY), Offset(pt.x + 5f, botY), strokeWidth = 2f)
                        }
                    }

                    // Connect with line
                    for (p in 0 until points.size - 1) {
                        drawLine(col, points[p], points[p + 1], strokeWidth = 3f)
                    }

                    // Draw marker points
                    points.forEach { pt ->
                        drawCircle(Color.White, radius = 6f, center = pt)
                        drawCircle(col, radius = 4.5f, center = pt)
                    }
                }
            }

            // Legend
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                levelsLines.forEachIndexed { idx, lineLvl ->
                    val col = lineColors[idx % lineColors.size]
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    ) {
                        Surface(
                            shape = MaterialTheme.shapes.extraSmall,
                            color = col,
                            modifier = Modifier.size(10.dp)
                        ) {}
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(lineLvl, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}

@Composable
fun AncovaAdjustedPlot(
    result: StatsMath.AncovaResult,
    modifier: Modifier = Modifier
) {
    if (result.adjustedMeans.isEmpty()) return

    val isDark = isSystemInDarkTheme()
    val canvasBg = if (isDark) Color(0xFF0F172A) else Color(0xFFFAFAFA)
    val axisColor = if (isDark) Color(0xFF64748B) else Color.Gray
    val textAndroidColor = if (isDark) android.graphics.Color.WHITE else android.graphics.Color.BLACK

    val allVals = result.adjustedMeans.flatMap { listOf(it.unadjustedMean, it.ciL, it.ciU) }
    val minVal = (allVals.minOrNull() ?: 0.0) - 1.0
    val maxVal = (allVals.maxOrNull() ?: 50.0) + 1.0
    val range = max(1.0, maxVal - minVal)

    ChartContainer(
        title = "Figure 4. ANCOVA: Estimated Marginal Means vs. Unadjusted Means",
        subtitle = "Means of ${result.dvName} across ${result.factorName} levels controlling for ${result.covariateName} (Covariate pooled slope b = ${StatsMath.formatNumber(result.covariateSlope)})",
        modifier = modifier
    ) { settings ->
        Column {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(canvasBg)
            ) {
                val w = size.width
                val h = size.height
                val padL = 45f
                val padR = 25f
                val padT = 25f
                val padB = 45f
                val plotW = w - padL - padR
                val plotH = h - padT - padB

                if (settings.showGridlines) {
                    for (g in 1..4) {
                        val yLine = (h - padB) - (g * 0.25f) * plotH
                        drawLine(Color.LightGray.copy(alpha = 0.35f), Offset(padL, yLine), Offset(w - padR, yLine))
                    }
                }

                // Reference line for grand mean
                val grandYPix = (h - padB) - ((result.grandMeanY - minVal) / range).toFloat() * plotH
                drawLine(
                    Color.Gray.copy(alpha = 0.5f),
                    Offset(padL, grandYPix),
                    Offset(w - padR, grandYPix),
                    strokeWidth = 1.5f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                )

                // Axes
                drawLine(axisColor, Offset(padL, h - padB), Offset(w - padR, h - padB), strokeWidth = 2f)
                drawLine(axisColor, Offset(padL, padT), Offset(padL, h - padB), strokeWidth = 2f)

                val labelPaint = android.graphics.Paint().apply {
                    color = textAndroidColor
                    textSize = 22f
                    textAlign = android.graphics.Paint.Align.CENTER
                    isAntiAlias = true
                }

                val nGroups = result.adjustedMeans.size
                val groupW = plotW / max(1, nGroups)

                result.adjustedMeans.forEachIndexed { i, m ->
                    val centerX = padL + i * groupW + groupW / 2f

                    // 1. Unadjusted Mean (circle in Gray)
                    val unadjY = (h - padB) - ((m.unadjustedMean - minVal) / range).toFloat() * plotH
                    drawCircle(Color(0xFF94A3B8), radius = 5.5f, center = Offset(centerX - 12f, unadjY))

                    // 2. Adjusted Mean (solid green in settings.theme.primary)
                    val adjY = (h - padB) - ((m.adjustedMean - minVal) / range).toFloat() * plotH
                    val ciTop = (h - padB) - ((m.ciU - minVal) / range).toFloat() * plotH
                    val ciBot = (h - padB) - ((m.ciL - minVal) / range).toFloat() * plotH

                    // CI error bar
                    drawLine(settings.theme.primary, Offset(centerX + 10f, ciTop), Offset(centerX + 10f, ciBot), strokeWidth = 2.5f)
                    drawLine(settings.theme.primary, Offset(centerX + 4f, ciTop), Offset(centerX + 16f, ciTop), strokeWidth = 2f)
                    drawLine(settings.theme.primary, Offset(centerX + 4f, ciBot), Offset(centerX + 16f, ciBot), strokeWidth = 2f)

                    // Point
                    drawCircle(settings.theme.primary, radius = 6f, center = Offset(centerX + 10f, adjY))

                    // X-axis label
                    val shortG = if (m.group.length > 8) m.group.take(7) + "…" else m.group
                    drawContext.canvas.nativeCanvas.drawText(shortG, centerX, h - padB + 28f, labelPaint)
                }
            }

            // Legend
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Text("○ Unadjusted Mean", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color(0xFF64748B))
                Text("● Adjusted Mean (with 95% CI)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = settings.theme.primary)
            }
        }
    }
}

@Composable
fun ScreePlot(
    eigenvalues: List<Double>,
    modifier: Modifier = Modifier
) {
    if (eigenvalues.isEmpty()) return
    val maxEig = max(2.5, (eigenvalues.maxOrNull() ?: 1.0) * 1.1)

    val isDark = isSystemInDarkTheme()
    val canvasBg = if (isDark) Color(0xFF0F172A) else Color(0xFFFAFAFA)
    val axisColor = if (isDark) Color(0xFF64748B) else Color.Gray

    ChartContainer(title = "Scree Plot (PCA / Factor Analysis)", subtitle = "Eigenvalues with Kaiser Criterion (λ = 1.0)", modifier = modifier) { settings ->
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(canvasBg)
        ) {
            val w = size.width
            val h = size.height
            val padL = 40f
            val padR = 20f
            val padT = 20f
            val padB = 40f
            val plotW = w - padL - padR
            val plotH = h - padT - padB

            if (settings.showGridlines) {
                for (g in 1..4) {
                    val yLine = (h - padB) - (g * 0.2f) * plotH
                    drawLine(Color.LightGray.copy(alpha = 0.35f), Offset(padL, yLine), Offset(w - padR, yLine))
                }
            }

            // Axes
            drawLine(axisColor, Offset(padL, h - padB), Offset(w - padR, h - padB), strokeWidth = 2f)
            drawLine(axisColor, Offset(padL, padT), Offset(padL, h - padB), strokeWidth = 2f)

            // Kaiser threshold λ = 1.0
            val y1Line = (h - padB) - (1.0 / maxEig).toFloat() * plotH
            drawLine(
                color = PlotCoral,
                start = Offset(padL, y1Line),
                end = Offset(w - padR, y1Line),
                strokeWidth = 2f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
            )

            val n = eigenvalues.size
            val stepX = plotW / (n + 1)
            val path = Path()

            val points = eigenvalues.mapIndexed { idx, eig ->
                val px = padL + (idx + 1) * stepX
                val py = (h - padB) - (eig / maxEig).toFloat() * plotH
                Offset(px, py)
            }

            points.forEachIndexed { i, pt ->
                if (i == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
            }
            drawPath(path, color = settings.theme.primary, style = Stroke(width = 3f))

            points.forEach { pt ->
                drawCircle(color = settings.theme.primary, radius = 5.5f, center = pt)
                drawCircle(color = Color.White, radius = 3f, center = pt)
            }
        }
    }
}

@Composable
fun MediationPathDiagram(
    xName: String,
    mName: String,
    yName: String,
    pathA: Double,
    pathB: Double,
    pathCPrime: Double,
    indirect: Double,
    modifier: Modifier = Modifier
) {
    val isDark = isSystemInDarkTheme()
    val canvasBg = if (isDark) Color(0xFF0F172A) else Color(0xFFFAFAFA)
    val nodeFill = if (isDark) Color(0xFF155E75) else JamoviTealContainer
    val nodeBorder = if (isDark) Color(0xFF22D3EE) else JamoviTeal
    val nodeTextAndroidColor = if (isDark) android.graphics.Color.WHITE else android.graphics.Color.parseColor("#164E63")

    ChartContainer(title = "Mediation Path Diagram (Baron & Kenny / Hayes)", subtitle = "Direct (c') and Indirect (a × b) Pathways", modifier = modifier) { settings ->
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(canvasBg)
        ) {
            val w = size.width
            val h = size.height

            val nodeX = Offset(w * 0.18f, h * 0.70f)
            val nodeM = Offset(w * 0.50f, h * 0.25f)
            val nodeY = Offset(w * 0.82f, h * 0.70f)
            val nodeR = 36f

            fun drawPathArrow(start: Offset, end: Offset, color: Color) {
                val dx = end.x - start.x
                val dy = end.y - start.y
                val dist = sqrt(dx * dx + dy * dy)
                val ux = dx / dist
                val uy = dy / dist
                val pStart = Offset(start.x + ux * nodeR, start.y + uy * nodeR)
                val pEnd = Offset(end.x - ux * (nodeR + 6f), end.y - uy * (nodeR + 6f))

                drawLine(color, pStart, pEnd, strokeWidth = 2.5f)
                val arrowSize = 10f
                val perpX = -uy * arrowSize * 0.6f
                val perpY = ux * arrowSize * 0.6f
                val arrowPath = Path().apply {
                    moveTo(pEnd.x, pEnd.y)
                    lineTo(pEnd.x - ux * arrowSize + perpX, pEnd.y - uy * arrowSize + perpY)
                    lineTo(pEnd.x - ux * arrowSize - perpX, pEnd.y - uy * arrowSize - perpY)
                    close()
                }
                drawPath(arrowPath, color)
            }

            drawPathArrow(nodeX, nodeM, settings.theme.primary)
            drawPathArrow(nodeM, nodeY, settings.theme.primary)
            drawPathArrow(nodeX, nodeY, PlotBlue)

            val textPaint = android.graphics.Paint().apply {
                color = nodeTextAndroidColor
                textSize = 26f
                textAlign = android.graphics.Paint.Align.CENTER
                isFakeBoldText = true
            }

            listOf(nodeX to xName, nodeM to mName, nodeY to yName).forEach { (pos, label) ->
                drawCircle(color = nodeFill, radius = nodeR, center = pos)
                drawCircle(color = nodeBorder, radius = nodeR, center = pos, style = Stroke(2f))
                drawContext.canvas.nativeCanvas.drawText(
                    label.take(6),
                    pos.x,
                    pos.y + 9f,
                    textPaint
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Text("a: ${StatsMath.formatNumber(pathA)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = settings.theme.primary)
            Text("b: ${StatsMath.formatNumber(pathB)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = settings.theme.primary)
            Text("c': ${StatsMath.formatNumber(pathCPrime)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PlotBlue)
            Text("ab: ${StatsMath.formatNumber(indirect)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PlotCoral)
        }
    }
}

@Composable
fun SemPathDiagram(
    semResult: StatsMath.SemResult,
    modifier: Modifier = Modifier
) {
    val isDark = isSystemInDarkTheme()
    val canvasBg = if (isDark) Color(0xFF0F172A) else Color(0xFFFAFAFA)
    val nodeFill = if (isDark) Color(0xFF155E75) else JamoviTealContainer
    val nodeBorder = if (isDark) Color(0xFF22D3EE) else JamoviTeal
    val nodeTextColor = if (isDark) android.graphics.Color.WHITE else android.graphics.Color.parseColor("#164E63")

    ChartContainer(
        title = "Figure 9. Structural Equation Model (SEM) Path Specification",
        subtitle = "CFI = ${StatsMath.formatNumber(semResult.cfi, 3)}, RMSEA = ${StatsMath.formatNumber(semResult.rmsea, 3)}",
        modifier = modifier
    ) { settings ->
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(230.dp)
                .background(canvasBg)
        ) {
            val w = size.width
            val h = size.height

            // Dynamic layout of nodes: Exogenous (left), Mediators (middle), Endogenous (right)
            val p1 = Offset(w * 0.18f, h * 0.30f)
            val p2 = Offset(w * 0.18f, h * 0.70f)
            val pM = Offset(w * 0.50f, h * 0.50f)
            val pY = Offset(w * 0.82f, h * 0.50f)
            val nodeR = 34f

            val textPaint = android.graphics.Paint().apply {
                color = nodeTextColor
                textSize = 24f
                textAlign = android.graphics.Paint.Align.CENTER
                isFakeBoldText = true
            }

            fun drawArrow(from: Offset, to: Offset, color: Color) {
                val dx = to.x - from.x
                val dy = to.y - from.y
                val dist = sqrt(dx * dx + dy * dy)
                val ux = dx / dist
                val uy = dy / dist
                val pStart = Offset(from.x + ux * nodeR, from.y + uy * nodeR)
                val pEnd = Offset(to.x - ux * (nodeR + 6f), to.y - uy * (nodeR + 6f))

                drawLine(color, pStart, pEnd, strokeWidth = 2.5f)
                val arrowSize = 10f
                val perpX = -uy * arrowSize * 0.6f
                val perpY = ux * arrowSize * 0.6f
                val arrowPath = Path().apply {
                    moveTo(pEnd.x, pEnd.y)
                    lineTo(pEnd.x - ux * arrowSize + perpX, pEnd.y - uy * arrowSize + perpY)
                    lineTo(pEnd.x - ux * arrowSize - perpX, pEnd.y - uy * arrowSize - perpY)
                    close()
                }
                drawPath(arrowPath, color)
            }

            drawArrow(p1, pM, settings.theme.primary)
            drawArrow(p2, pM, settings.theme.primary)
            drawArrow(pM, pY, settings.theme.accent)
            drawArrow(p1, pY, PlotBlue)

            // Draw nodes
            listOf(p1 to "X1", p2 to "X2", pM to "Med", pY to "Out").forEach { (pos, lbl) ->
                drawCircle(color = nodeFill, radius = nodeR, center = pos)
                drawCircle(color = nodeBorder, radius = nodeR, center = pos, style = Stroke(2f))
                drawContext.canvas.nativeCanvas.drawText(lbl, pos.x, pos.y + 8f, textPaint)
            }
        }
    }
}

@Composable
fun PowerCurvePlot(
    effectSize: Double,
    alpha: Double,
    modifier: Modifier = Modifier
) {
    val isDark = isSystemInDarkTheme()
    val canvasBg = if (isDark) Color(0xFF0F172A) else Color(0xFFFAFAFA)
    val axisColor = if (isDark) Color(0xFF64748B) else Color.Gray

    ChartContainer(title = "Statistical Power vs. Sample Size Curve", subtitle = "Target 80% Power Threshold with α = $alpha", modifier = modifier) { settings ->
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .background(canvasBg)
        ) {
            val w = size.width
            val h = size.height
            val padL = 40f
            val padR = 20f
            val padT = 20f
            val padB = 40f
            val plotW = w - padL - padR
            val plotH = h - padT - padB

            if (settings.showGridlines) {
                for (g in 1..4) {
                    val yLine = (h - padB) - (g * 0.2f) * plotH
                    drawLine(Color.LightGray.copy(alpha = 0.35f), Offset(padL, yLine), Offset(w - padR, yLine))
                }
            }

            drawLine(axisColor, Offset(padL, h - padB), Offset(w - padR, h - padB), strokeWidth = 2f)
            drawLine(axisColor, Offset(padL, padT), Offset(padL, h - padB), strokeWidth = 2f)

            // 80% horizontal threshold line
            val y80 = (h - padB) - 0.80f * plotH
            drawLine(
                color = PlotCoral,
                start = Offset(padL, y80),
                end = Offset(w - padR, y80),
                strokeWidth = 2f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
            )

            val maxN = 150
            val curvePath = Path()
            for (currN in 10..maxN step 4) {
                val pwr = StatsMath.calculatePower(effectSize, alpha, currN, "t-Test (Independent)").calculatedPower
                val px = padL + (currN.toFloat() / maxN) * plotW
                val py = (h - padB) - pwr.toFloat() * plotH
                if (currN == 10) curvePath.moveTo(px, py) else curvePath.lineTo(px, py)
            }
            drawPath(curvePath, color = settings.theme.primary, style = Stroke(width = 3.5f))
        }
    }
}
