package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Luxury Dark Green & Pure White Signature Palette
val LuxuryDarkGreen = Color(0xFF143D2B)       // Rich luxury dark emerald / British racing green
val LuxuryDarkGreenVariant = Color(0xFF1E533C)
val LuxuryForestGreen = Color(0xFF2D6A4F)      // Elegant medium green
val LuxuryGreenLight = Color(0xFF52B788)
val LuxuryGreenContainer = Color(0xFFE8F5E9)   // Pale luxury mint container
val LuxuryOnGreenContainer = Color(0xFF0F382A)
val LuxuryGoldAccent = Color(0xFFD4AF37)       // Luxury gold touch

// Backwards-compatible Jamovi aliases mapped to Luxury Dark Green theme
val JamoviTeal = LuxuryDarkGreen
val JamoviTealDark = Color(0xFF0D2E20)
val JamoviTealLight = LuxuryForestGreen
val JamoviTealContainer = LuxuryGreenContainer
val JamoviOnTealContainer = LuxuryOnGreenContainer

val JamoviSlate = Color(0xFF16241D)          // Crisp dark charcoal with subtle green tone
val JamoviSlateLight = Color(0xFF384B42)
val JamoviCanvas = Color(0xFFFFFFFF)         // Pristine White Canvas
val JamoviSurface = Color(0xFFFFFFFF)        // Pure White Surface

val ApaTableRule = Color(0xFF16241D)         // APA 7th edition crisp rule
val ApaTableSubtleRule = Color(0xFFCBD7D0)   // Subtle luxury table divider
val ApaTableHeaderBg = Color(0xFFF5FAF7)     // Pristine luxury subtle header background

// Plot Colors (Publication standards with luxury dark green harmony)
val PlotEmerald = Color(0xFF143D2B)
val PlotBlue = Color(0xFF2563EB)
val PlotCyan = Color(0xFF0D9488)
val PlotCoral = Color(0xFFE11D48)
val PlotAmber = Color(0xFFD97706)
val PlotPurple = Color(0xFF7C3AED)
