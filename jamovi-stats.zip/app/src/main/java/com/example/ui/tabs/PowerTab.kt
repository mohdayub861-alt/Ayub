package com.example.ui.tabs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.model.Dataset
import com.example.stats.StatsMath
import com.example.ui.components.*
import kotlin.math.*

@Composable
fun PowerTab(
    dataset: Dataset,
    modifier: Modifier = Modifier
) {
    var testType by remember { mutableStateOf("t-Test (Independent)") }
    var effectSizeInput by remember { mutableStateOf("0.50") } // medium effect
    var alphaInput by remember { mutableStateOf("0.05") }
    var sampleSizeInput by remember { mutableStateOf("${max(20, dataset.rowCount)}") }

    val effectSize = effectSizeInput.toDoubleOrNull() ?: 0.50
    val alpha = alphaInput.toDoubleOrNull() ?: 0.05
    val n = sampleSizeInput.toIntOrNull() ?: 20

    val powerResult = StatsMath.calculatePower(effectSize, alpha, n, testType)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Select Statistical Test:", style = MaterialTheme.typography.titleSmall)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("t-Test (Independent)", "t-Test (Paired)", "One-Way ANOVA", "Correlation r").forEach { t ->
                            FilterChip(
                                selected = testType == t,
                                onClick = { testType = t },
                                label = { Text(t) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = effectSizeInput,
                            onValueChange = { effectSizeInput = it },
                            label = { Text("Effect Size (${powerResult.effectSizeMetric})") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = alphaInput,
                            onValueChange = { alphaInput = it },
                            label = { Text("Alpha (α)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = sampleSizeInput,
                            onValueChange = { sampleSizeInput = it },
                            label = { Text("Sample Size (N)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // APA Table 10: Statistical Power Summary
        item {
            val tableCols = listOf(
                TableColumn("Design", width = 140),
                TableColumn("Effect Size", width = 95),
                TableColumn("α", width = 60, isSymbol = true),
                TableColumn("N", width = 60, isSymbol = true),
                TableColumn("Achieved Power", width = 110),
                TableColumn("Req. N (80%)", width = 100),
                TableColumn("Req. N (90%)", width = 100),
                TableColumn("95% CI Lower", width = 95),
                TableColumn("95% CI Upper", width = 95)
            )

            val rows = listOf(
                listOf(
                    testType,
                    "${powerResult.effectSizeMetric} = ${StatsMath.formatNumber(effectSize)}",
                    StatsMath.formatNumber(alpha),
                    n.toString(),
                    "${StatsMath.formatNumber(powerResult.calculatedPower * 100, 1)}%",
                    powerResult.requiredNFor80.toString(),
                    powerResult.requiredNFor90.toString(),
                    StatsMath.formatNumber(powerResult.ciL),
                    StatsMath.formatNumber(powerResult.ciU)
                )
            )

            val narrative = "An a priori and post hoc statistical power analysis was conducted for a $testType with α = $alpha and an anticipated effect size of ${powerResult.effectSizeMetric} = ${StatsMath.formatNumber(effectSize)}. With the current sample size of N = $n, achieved power was 1 - β = ${StatsMath.formatNumber(powerResult.calculatedPower, 3)}. To ensure standard 80% statistical power (β = .20), a minimum total sample size of N = ${powerResult.requiredNFor80} is required."

            ApaTable(
                tableNumber = "Table 10",
                tableTitle = "Statistical Power Estimates and Required Sample Sizes",
                columns = tableCols,
                rows = rows,
                note = "Power calculations performed using non-central distribution algorithms. Req. N = required sample size to achieve 80% and 90% power thresholds at α = $alpha.",
                inTextReport = narrative
            )
        }

        // Effect Size Conversion Table
        item {
            val d = abs(effectSize)
            val rFromD = d / sqrt(d * d + 4.0)
            val etaSqFromD = (d * d) / (d * d + 4.0)
            val orFromD = exp(d * Math.PI / sqrt(3.0))

            val convCols = listOf(
                TableColumn("Metric", width = 140),
                TableColumn("Equivalent Value", width = 120),
                TableColumn("Cohen's Benchmark", width = 140),
                TableColumn("Interpretation", width = 120)
            )

            val convRows = listOf(
                listOf("Cohen's d", StatsMath.formatNumber(d), "0.20 Small, 0.50 Medium, 0.80 Large", if (d >= 0.8) "Large" else if (d >= 0.5) "Medium" else "Small"),
                listOf("Pearson's r", StatsMath.formatNumber(rFromD), "0.10 Small, 0.30 Medium, 0.50 Large", if (rFromD >= 0.5) "Large" else if (rFromD >= 0.3) "Medium" else "Small"),
                listOf("Eta-Squared (η²)", StatsMath.formatNumber(etaSqFromD), "0.01 Small, 0.06 Medium, 0.14 Large", if (etaSqFromD >= 0.14) "Large" else if (etaSqFromD >= 0.06) "Medium" else "Small"),
                listOf("Odds Ratio (OR)", StatsMath.formatNumber(orFromD), "1.50 Small, 2.50 Medium, 4.00 Large", if (orFromD >= 4.0) "Large" else if (orFromD >= 2.5) "Medium" else "Small")
            )

            ApaTable(
                tableNumber = "Table 10b",
                tableTitle = "Effect Size Conversion and Benchmark Equivalencies",
                columns = convCols,
                rows = convRows,
                note = "Transformations follow Cohen (1988) and Borenstein et al. (2009) meta-analytic formulas."
            )
        }

        // Power vs Sample Size Plot
        item {
            PowerCurvePlot(
                effectSize = effectSize,
                alpha = alpha
            )
        }
    }
}
