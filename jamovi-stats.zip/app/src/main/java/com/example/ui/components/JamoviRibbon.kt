package com.example.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.JamoviTeal
import com.example.ui.theme.JamoviTealLight

enum class JamoviTab(val title: String, val subtitle: String, val icon: ImageVector) {
    DATA("Data", "Spreadsheet Grid", Icons.Default.TableChart),
    DESCRIPTIVES("Descriptives", "Summary, Frequencies, Plots", Icons.Default.Analytics),
    T_TESTS("t-Tests", "One-sample, Independent, Paired", Icons.Default.CompareArrows),
    ANOVA("ANOVA", "One-way, Mixed, Factorial, ANCOVA", Icons.Default.BarChart),
    NON_PARAMETRIC("Non-parametric", "Mann-Whitney, Kruskal, χ²", Icons.Default.FilterList),
    CORRELATION("Correlation", "Pearson, Spearman, Partial", Icons.Default.Grain),
    REGRESSION("Regression", "Linear, Hierarchical, Logistic", Icons.AutoMirrored.Filled.TrendingUp),
    RELIABILITY("Reliability", "Alpha, Omega, Item analysis", Icons.Default.VerifiedUser),
    FACTOR_ANALYSIS("Factor", "EFA, PCA, CFA fit indices", Icons.Default.ScatterPlot),
    MEDIATION_SEM("Mediation & SEM", "Mediation, Moderation, SEM Path", Icons.Default.AccountTree),
    POWER("Power", "Sample size, Effect sizes", Icons.Default.Speed)
}

@Composable
fun JamoviRibbon(
    currentTab: JamoviTab,
    onTabSelected: (JamoviTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    // Luxury dark green header
    Surface(
        color = Color(0xFF143D2B),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState)
                .padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            JamoviTab.values().forEach { tab ->
                val isSelected = tab == currentTab
                val containerColor = if (isSelected) Color(0xFF2D6A4F) else Color.Transparent
                val contentColor = if (isSelected) Color.White else Color(0xFFD6E6DE)

                Button(
                    onClick = { onTabSelected(tab) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = containerColor,
                        contentColor = contentColor
                    ),
                    shape = MaterialTheme.shapes.small,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.padding(horizontal = 2.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = tab.icon,
                            contentDescription = tab.title,
                            tint = if (isSelected) Color.White else JamoviTealLight,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = tab.title,
                            fontSize = 12.5.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}
