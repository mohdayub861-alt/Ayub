package com.example.ui.tabs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.Dataset
import com.example.model.VariableType
import com.example.stats.StatsMath
import com.example.ui.components.*

@Composable
fun DescriptivesTab(
    dataset: Dataset,
    modifier: Modifier = Modifier
) {
    val allCols = dataset.columns
    var selectedColIds by remember(dataset) {
        mutableStateOf(allCols.take(4).map { it.id }.toSet())
    }

    val selectedColumns = allCols.filter { selectedColIds.contains(it.id) }
    val scaleColumns = selectedColumns.filter { it.type == VariableType.SCALE || it.getValidDoubles().size >= 3 }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    VariableChipRow(
                        title = "Select Variables to Analyze (Summary Statistics & Frequencies):",
                        availableColumns = allCols,
                        selectedIds = selectedColIds,
                        onToggleColumn = { colId ->
                            selectedColIds = if (selectedColIds.contains(colId)) {
                                if (selectedColIds.size > 1) selectedColIds - colId else selectedColIds
                            } else {
                                selectedColIds + colId
                            }
                        }
                    )
                }
            }
        }

        if (selectedColumns.isNotEmpty()) {
            // Table 1: APA Summary Statistics for Scale / Numeric variables
            if (scaleColumns.isNotEmpty()) {
                val results = scaleColumns.map { col ->
                    StatsMath.calculateDescriptives(col.getValidDoubles(), col.name)
                }

                item {
                    val tableCols = listOf(
                        TableColumn("Variable", width = 110),
                        TableColumn("N", width = 55, isSymbol = true),
                        TableColumn("M", width = 75, isSymbol = true),
                        TableColumn("Median", width = 75),
                        TableColumn("SD", width = 70, isSymbol = true),
                        TableColumn("SE", width = 70, isSymbol = true),
                        TableColumn("Min", width = 65),
                        TableColumn("Max", width = 65),
                        TableColumn("Skewness", width = 85),
                        TableColumn("Kurtosis", width = 85),
                        TableColumn("W", width = 65, isSymbol = true),
                        TableColumn("p", width = 70, isSymbol = true)
                    )

                    val rows = results.map { r ->
                        listOf(
                            r.varName,
                            r.n.toString(),
                            StatsMath.formatNumber(r.mean),
                            StatsMath.formatNumber(r.median),
                            StatsMath.formatNumber(r.sd),
                            StatsMath.formatNumber(r.se),
                            StatsMath.formatNumber(r.min),
                            StatsMath.formatNumber(r.max),
                            StatsMath.formatNumber(r.skewness),
                            StatsMath.formatNumber(r.kurtosis),
                            StatsMath.formatNumber(r.shapiroW),
                            StatsMath.formatPValue(r.shapiroP)
                        )
                    }

                    val primary = results.first()
                    val narrative = "Descriptive statistics for ${primary.varName} (N = ${primary.n}) revealed M = ${StatsMath.formatNumber(primary.mean)}, SD = ${StatsMath.formatNumber(primary.sd)}, with range [${StatsMath.formatNumber(primary.min)}, ${StatsMath.formatNumber(primary.max)}]. The Shapiro-Wilk test of normality yielded W = ${StatsMath.formatNumber(primary.shapiroW)}, p ${StatsMath.formatPValue(primary.shapiroP)}."

                    ApaTable(
                        tableNumber = "Table 1",
                        tableTitle = "Descriptive Statistics and Normality Tests for Study Measures",
                        columns = tableCols,
                        rows = rows,
                        note = "N = sample size; M = mean; SD = standard deviation; SE = standard error of the mean; W = Shapiro-Wilk normality test statistic.",
                        inTextReport = narrative
                    )
                }
            }

            // FREQUENCY TABLES FOR ALL SELECTED VARIABLES (As requested by user!)
            item {
                Text(
                    text = "Frequency Tables for Selected Variables",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            selectedColumns.forEachIndexed { idx, col ->
                val freqTable = StatsMath.calculateFrequencyTable(
                    rawValues = col.values,
                    varName = col.name,
                    isScale = col.type == VariableType.SCALE
                )

                item(key = "freq_${col.id}") {
                    val freqCols = listOf(
                        TableColumn(if (col.type == VariableType.SCALE) "Score Interval" else "Category Level", width = 140),
                        TableColumn("Counts (f)", width = 85, isSymbol = true),
                        TableColumn("% of Total", width = 85),
                        TableColumn("Cumulative %", width = 105)
                    )

                    val freqRows = freqTable.rows.map { fRow ->
                        listOf(
                            fRow.level,
                            fRow.count.toString(),
                            "${StatsMath.formatNumber(fRow.percent, 1)}%",
                            "${StatsMath.formatNumber(fRow.cumPercent, 1)}%"
                        )
                    }

                    val typeLabel = "${col.type.symbol} ${col.type.label}"
                    val narrative = "Frequency distribution for ${col.name} ($typeLabel, N = ${freqTable.totalN}): most frequent category was '${freqTable.rows.firstOrNull()?.level ?: "—"}' with ${freqTable.rows.firstOrNull()?.count ?: 0} occurrences (${StatsMath.formatNumber(freqTable.rows.firstOrNull()?.percent ?: 0.0, 1)}%)."

                    ApaTable(
                        tableNumber = "Table 1.${idx + 1}",
                        tableTitle = "Frequency Distribution for ${col.name} ($typeLabel)",
                        columns = freqCols,
                        rows = freqRows,
                        note = "Total N = ${freqTable.totalN}${if (freqTable.missingN > 0) ", Missing = ${freqTable.missingN}" else ""}. Percentages are relative to valid observations.",
                        inTextReport = narrative
                    )
                }

                // Independent frequency plot for each selected variable
                item(key = "plot_${col.id}") {
                    IndependentFrequencyPlot(
                        varName = col.name,
                        freqTable = freqTable
                    )
                }
            }

            // Comparative Distribution Graphs for Scale Variables
            if (scaleColumns.isNotEmpty()) {
                item {
                    Text(
                        text = "Comparative Multi-Variable Visualizations",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                item {
                    val firstCol = scaleColumns.first()
                    val data = firstCol.getValidDoubles()
                    DensityHistogramPlot(
                        data = data,
                        title = "Figure 2. Distribution and Fitted Normal Density for ${firstCol.name}"
                    )
                }

                item {
                    val groupMap = scaleColumns.associate { col ->
                        col.name to col.getValidDoubles()
                    }
                    BoxPlotWithJitter(
                        groups = groupMap,
                        title = "Figure 3. Comparative Boxplots with Jittered Observations for Selected Variables"
                    )
                }
            }
        }
    }
}
