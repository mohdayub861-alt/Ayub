package com.example.ui.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Dataset
import com.example.model.VariableType
import com.example.stats.StatsMath
import com.example.ui.components.*
import com.example.ui.theme.LuxuryDarkGreen
import com.example.ui.theme.LuxuryForestGreen
import com.example.ui.theme.LuxuryGreenContainer

@Composable
fun AnovaTab(
    dataset: Dataset,
    modifier: Modifier = Modifier
) {
    var selectedAnovaIndex by remember { mutableIntStateOf(0) } // 0: One-Way (Fixed), 1: Factorial, 2: Mixed ANOVA, 3: ANCOVA
    val anovaTypes = listOf("One-Way ANOVA", "Factorial ANOVA", "Mixed ANOVA", "ANCOVA")

    val continuousCols = remember(dataset) {
        val filtered = dataset.columns.filter { it.type == VariableType.SCALE || it.getValidDoubles().size >= 3 }
        filtered.ifEmpty { dataset.columns }
    }
    val categoricalCols = remember(dataset) {
        val filtered = dataset.columns.filter { it.type == VariableType.NOMINAL || it.type == VariableType.ORDINAL }
        filtered.ifEmpty { dataset.columns }
    }

    // Single / Factorial / ANCOVA Variables
    var selectedDvId by remember(dataset) {
        mutableStateOf(continuousCols.firstOrNull()?.id)
    }
    var selectedFactorId by remember(dataset) {
        mutableStateOf(categoricalCols.firstOrNull()?.id)
    }
    var selectedFactor2Id by remember(dataset) {
        mutableStateOf(categoricalCols.getOrNull(1)?.id ?: dataset.columns.getOrNull(1)?.id)
    }
    var selectedCovariateId by remember(dataset) {
        mutableStateOf(continuousCols.getOrNull(1)?.id)
    }

    // For Mixed ANOVA: between-subjects factor + within-subjects repeated measures
    var mixedBetweenFactorId by remember(dataset) {
        mutableStateOf(categoricalCols.firstOrNull()?.id)
    }
    var mixedRepeatedTimeIds by remember(dataset) {
        val timeCandidates = continuousCols.filter {
            it.name.contains("test", ignoreCase = true) ||
            it.name.contains("score", ignoreCase = true) ||
            it.name.contains("time", ignoreCase = true) ||
            it.name.contains("base", ignoreCase = true) ||
            it.name.contains("follow", ignoreCase = true)
        }
        val defaultSelection = if (timeCandidates.size >= 2) {
            timeCandidates.take(3).map { it.id }.toSet()
        } else {
            continuousCols.take(3).map { it.id }.toSet()
        }
        mutableStateOf(defaultSelection)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top ANOVA Subtabs with Luxury Dark Green Styling
        ScrollableTabRow(
            selectedTabIndex = selectedAnovaIndex,
            containerColor = LuxuryDarkGreen,
            contentColor = Color.White,
            edgePadding = 8.dp
        ) {
            anovaTypes.forEachIndexed { idx, title ->
                val isSel = selectedAnovaIndex == idx
                Tab(
                    selected = isSel,
                    onClick = { selectedAnovaIndex = idx },
                    text = {
                        Text(
                            text = title,
                            fontSize = 13.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSel) Color.White else Color(0xFFD3E4DB)
                        )
                    },
                    icon = {
                        val icon = when (idx) {
                            0 -> Icons.Default.BarChart
                            1 -> Icons.Default.Tune
                            2 -> Icons.Default.Timeline
                            else -> Icons.Default.CompareArrows
                        }
                        Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp), tint = if (isSel) Color.White else Color(0xFFA1C4B4))
                    }
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Configuration Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "${anovaTypes[selectedAnovaIndex]} Model Specification",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = LuxuryDarkGreen
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        if (selectedAnovaIndex == 2) {
                            // MIXED ANOVA: Between-Subjects Factor & Within-Subjects Repeated Measures
                            SingleVariableSelector(
                                title = "Between-Subjects Factor (Grouping Variable):",
                                availableColumns = categoricalCols.ifEmpty { dataset.columns },
                                selectedId = mixedBetweenFactorId,
                                onSelectColumn = { mixedBetweenFactorId = it }
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            VariableChipRow(
                                title = "Within-Subjects Repeated Measures (Time 1, Time 2, Time 3...):",
                                availableColumns = continuousCols,
                                selectedIds = mixedRepeatedTimeIds,
                                onToggleColumn = { tId ->
                                    mixedRepeatedTimeIds = if (mixedRepeatedTimeIds.contains(tId)) {
                                        if (mixedRepeatedTimeIds.size > 2) mixedRepeatedTimeIds - tId else mixedRepeatedTimeIds
                                    } else {
                                        mixedRepeatedTimeIds + tId
                                    }
                                }
                            )
                        } else {
                            SingleVariableSelector(
                                title = "Dependent Variable (Continuous / Scale):",
                                availableColumns = continuousCols,
                                selectedId = selectedDvId,
                                onSelectColumn = { selectedDvId = it }
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            SingleVariableSelector(
                                title = "Primary Fixed Factor (Factor A):",
                                availableColumns = categoricalCols.ifEmpty { dataset.columns },
                                selectedId = selectedFactorId,
                                onSelectColumn = { selectedFactorId = it }
                            )

                            if (selectedAnovaIndex == 1) {
                                // Factorial ANOVA: Second Fixed Factor
                                Spacer(modifier = Modifier.height(8.dp))
                                SingleVariableSelector(
                                    title = "Second Fixed Factor (Factor B):",
                                    availableColumns = categoricalCols.filter { it.id != selectedFactorId }.ifEmpty { dataset.columns.filter { it.id != selectedFactorId } },
                                    selectedId = selectedFactor2Id,
                                    onSelectColumn = { selectedFactor2Id = it }
                                )
                            }

                            if (selectedAnovaIndex == 3) {
                                // ANCOVA: Covariate
                                Spacer(modifier = Modifier.height(8.dp))
                                SingleVariableSelector(
                                    title = "Covariate (Continuous Baseline Measure):",
                                    availableColumns = continuousCols.filter { it.id != selectedDvId },
                                    selectedId = selectedCovariateId,
                                    onSelectColumn = { selectedCovariateId = it }
                                )
                            }
                        }
                    }
                }
            }

            // Calculation & APA Output
            when (selectedAnovaIndex) {
                // ==========================================
                // 0: ONE-WAY (FIXED FACTOR) ANOVA
                // ==========================================
                0 -> {
                    val dvCol = dataset.columns.find { it.id == selectedDvId }
                    val factorCol = dataset.columns.find { it.id == selectedFactorId }

                    if (dvCol != null && factorCol != null) {
                        val grouped = mutableMapOf<String, MutableList<Double>>()
                        val n = minOf(dvCol.values.size, factorCol.values.size)
                        for (i in 0 until n) {
                            val v = dvCol.values[i].toDoubleOrNull()
                            val g = factorCol.values[i].trim()
                            if (v != null && g.isNotEmpty()) {
                                grouped.getOrPut(g) { mutableListOf() }.add(v)
                            }
                        }

                        if (grouped.size >= 2) {
                            val result = StatsMath.oneWayAnova(grouped, factorCol.name)
                            val factorRow = result.table.first()

                            val narrative = "A one-way fixed-effects analysis of variance (ANOVA) was conducted on ${dvCol.name} across levels of ${factorCol.name}. The effect was ${if (factorRow.p < 0.05) "statistically significant" else "non-significant"}, F(${StatsMath.formatNumber(factorRow.df, 0)}, ${StatsMath.formatNumber(result.table[1].df, 0)}) = ${StatsMath.formatNumber(factorRow.f)}, p ${StatsMath.formatPValue(factorRow.p)}, η² = ${StatsMath.formatNumber(factorRow.etaSq)}."

                            val anovaColumns = listOf(
                                TableColumn("Source", width = 130),
                                TableColumn("SS", width = 85, isSymbol = true),
                                TableColumn("df", width = 50, isSymbol = true),
                                TableColumn("MS", width = 85, isSymbol = true),
                                TableColumn("F", width = 75, isSymbol = true),
                                TableColumn("p", width = 75, isSymbol = true),
                                TableColumn("η²", width = 75, isSymbol = true)
                            )

                            val anovaRows = result.table.map { row ->
                                listOf(
                                    row.source,
                                    StatsMath.formatNumber(row.ss),
                                    StatsMath.formatNumber(row.df, 0),
                                    StatsMath.formatNumber(row.ms),
                                    if (row.f.isNaN()) "—" else StatsMath.formatNumber(row.f),
                                    if (row.p.isNaN()) "—" else StatsMath.formatPValue(row.p),
                                    if (row.etaSq.isNaN()) "—" else StatsMath.formatNumber(row.etaSq)
                                )
                            }

                            item {
                                ApaTable(
                                    tableNumber = "Table 3",
                                    tableTitle = "One-Way Fixed-Effects ANOVA Summary for ${dvCol.name} by ${factorCol.name}",
                                    columns = anovaColumns,
                                    rows = anovaRows,
                                    note = "SS = sum of squares; df = degrees of freedom; MS = mean square; F = Fisher's F ratio; η² = eta-squared effect size.",
                                    inTextReport = narrative
                                )
                            }

                            if (result.postHoc.isNotEmpty()) {
                                item {
                                    val postHocCols = listOf(
                                        TableColumn("Comparison", width = 140),
                                        TableColumn("Mean Diff", width = 85),
                                        TableColumn("SE", width = 75, isSymbol = true),
                                        TableColumn("t", width = 70, isSymbol = true),
                                        TableColumn("p (Tukey)", width = 85),
                                        TableColumn("Cohen's d", width = 80, isSymbol = true)
                                    )
                                    val postHocRows = result.postHoc.map { ph ->
                                        listOf(
                                            ph.comparison,
                                            StatsMath.formatNumber(ph.meanDiff),
                                            StatsMath.formatNumber(ph.se),
                                            StatsMath.formatNumber(ph.t),
                                            StatsMath.formatPValue(ph.pTukey),
                                            StatsMath.formatNumber(ph.cohenD)
                                        )
                                    }

                                    ApaTable(
                                        tableNumber = "Table 3b",
                                        tableTitle = "Post-Hoc Pairwise Comparisons (Tukey HSD)",
                                        columns = postHocCols,
                                        rows = postHocRows,
                                        note = "Tukey Honestly Significant Difference (HSD) adjustment for familywise error rate."
                                    )
                                }
                            }

                            item {
                                BoxPlotWithJitter(
                                    groups = grouped,
                                    title = "Figure 3. Distribution of ${dvCol.name} Across ${factorCol.name} Conditions"
                                )
                            }
                        } else {
                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = LuxuryGreenContainer.copy(alpha = 0.5f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text("Select a grouping variable with at least two distinct groups.", fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }
                }

                // ==========================================
                // 1: FACTORIAL ANOVA (TWO-WAY FIXED EFFECTS)
                // ==========================================
                1 -> {
                    val dvCol = dataset.columns.find { it.id == selectedDvId }
                    val factorACol = dataset.columns.find { it.id == selectedFactorId }
                    val factorBCol = dataset.columns.find { it.id == selectedFactor2Id }

                    if (dvCol != null && factorACol != null && factorBCol != null) {
                        val n = minOf(dvCol.values.size, factorACol.values.size, factorBCol.values.size)
                        val validDoubles = mutableListOf<Double>()
                        val validA = mutableListOf<String>()
                        val validB = mutableListOf<String>()

                        for (i in 0 until n) {
                            val yVal = dvCol.values[i].toDoubleOrNull()
                            val aVal = factorACol.values[i].trim()
                            val bVal = factorBCol.values[i].trim()
                            if (yVal != null && aVal.isNotBlank() && bVal.isNotBlank()) {
                                validDoubles.add(yVal)
                                validA.add(aVal)
                                validB.add(bVal)
                            }
                        }

                        if (validDoubles.size >= 4 && validA.distinct().size >= 2 && validB.distinct().size >= 2) {
                            val factResult = StatsMath.factorialAnova(
                                y = validDoubles,
                                factorA = validA,
                                factorB = validB,
                                dvName = dvCol.name,
                                factorAName = factorACol.name,
                                factorBName = factorBCol.name
                            )

                            val rowA = factResult.rows[0]
                            val rowB = factResult.rows[1]
                            val rowAB = factResult.rows[2]

                            val narrative = "A 2-way factorial ANOVA was conducted to examine the effects of ${factorACol.name} and ${factorBCol.name} on ${dvCol.name}. The main effect of ${factorACol.name} was ${if (rowA.p < 0.05) "statistically significant" else "non-significant"}, F(${StatsMath.formatNumber(rowA.df, 0)}, ${StatsMath.formatNumber(factResult.rows[3].df, 0)}) = ${StatsMath.formatNumber(rowA.f)}, p ${StatsMath.formatPValue(rowA.p)}, partial η² = ${StatsMath.formatNumber(rowA.partialEtaSq)}. The main effect of ${factorBCol.name} was ${if (rowB.p < 0.05) "statistically significant" else "non-significant"}, F(${StatsMath.formatNumber(rowB.df, 0)}, ${StatsMath.formatNumber(factResult.rows[3].df, 0)}) = ${StatsMath.formatNumber(rowB.f)}, p ${StatsMath.formatPValue(rowB.p)}, partial η² = ${StatsMath.formatNumber(rowB.partialEtaSq)}. The ${factorACol.name} × ${factorBCol.name} interaction was ${if (rowAB.p < 0.05) "statistically significant" else "non-significant"}, F(${StatsMath.formatNumber(rowAB.df, 0)}, ${StatsMath.formatNumber(factResult.rows[3].df, 0)}) = ${StatsMath.formatNumber(rowAB.f)}, p ${StatsMath.formatPValue(rowAB.p)}, partial η² = ${StatsMath.formatNumber(rowAB.partialEtaSq)}."

                            val factCols = listOf(
                                TableColumn("Source", width = 140),
                                TableColumn("Type III SS", width = 90),
                                TableColumn("df", width = 50, isSymbol = true),
                                TableColumn("MS", width = 85, isSymbol = true),
                                TableColumn("F", width = 75, isSymbol = true),
                                TableColumn("p", width = 75, isSymbol = true),
                                TableColumn("Partial η²", width = 85, isSymbol = true)
                            )

                            val factRows = factResult.rows.map { row ->
                                listOf(
                                    row.source,
                                    StatsMath.formatNumber(row.ss),
                                    StatsMath.formatNumber(row.df, 0),
                                    StatsMath.formatNumber(row.ms),
                                    if (row.f.isNaN()) "—" else StatsMath.formatNumber(row.f),
                                    if (row.p.isNaN()) "—" else StatsMath.formatPValue(row.p),
                                    if (row.partialEtaSq.isNaN()) "—" else StatsMath.formatNumber(row.partialEtaSq)
                                )
                            }

                            item {
                                ApaTable(
                                    tableNumber = "Table 3",
                                    tableTitle = "Two-Way Factorial ANOVA Summary for ${dvCol.name}",
                                    columns = factCols,
                                    rows = factRows,
                                    note = "Design: ${factorACol.name} (${factResult.levelsA.size} levels) × ${factorBCol.name} (${factResult.levelsB.size} levels). Total N = ${factResult.totalN}.",
                                    inTextReport = narrative
                                )
                            }

                            // Factorial Cell Means Table
                            item {
                                val cellCols = listOf(
                                    TableColumn(factorACol.name, width = 110),
                                    TableColumn(factorBCol.name, width = 110),
                                    TableColumn("n", width = 50, isSymbol = true),
                                    TableColumn("Mean", width = 80, isSymbol = true),
                                    TableColumn("SD", width = 80, isSymbol = true),
                                    TableColumn("SE", width = 80, isSymbol = true)
                                )
                                val cellRows = factResult.cellMeans.map { cm ->
                                    listOf(
                                        cm.levelA,
                                        cm.levelB,
                                        cm.n.toString(),
                                        StatsMath.formatNumber(cm.mean),
                                        StatsMath.formatNumber(cm.sd),
                                        StatsMath.formatNumber(cm.se)
                                    )
                                }

                                ApaTable(
                                    tableNumber = "Table 3b",
                                    tableTitle = "Cell Means and Standard Errors for ${factorACol.name} × ${factorBCol.name}",
                                    columns = cellCols,
                                    rows = cellRows,
                                    note = "Values represent sample cell descriptive statistics."
                                )
                            }

                            // Interaction Plot
                            item {
                                FactorialInteractionPlot(result = factResult)
                            }
                        } else {
                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = LuxuryGreenContainer.copy(alpha = 0.5f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text("Please ensure both factors have at least 2 distinct categories and valid observations.", fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }
                }

                // ==========================================
                // 2: MIXED ANOVA
                // ==========================================
                2 -> {
                    val factorCol = dataset.columns.find { it.id == mixedBetweenFactorId }
                    val timeCols = continuousCols.filter { mixedRepeatedTimeIds.contains(it.id) }

                    if (factorCol != null && timeCols.size >= 2) {
                        val repeatedData = timeCols.map { it.getValidDoubles() }
                        val groupValues = factorCol.values

                        val mixedResult = StatsMath.mixedAnova(
                            betweenGroups = groupValues,
                            repeatedTimeCols = repeatedData,
                            timeLabels = timeCols.map { it.name },
                            betweenFactorName = factorCol.name
                        )

                        val betweenMain = mixedResult.betweenRows.first()
                        val timeMain = mixedResult.withinRows.first()
                        val interMain = mixedResult.withinRows[1]

                        val narrative = "A mixed ANOVA was conducted with ${factorCol.name} as between-subjects factor and repeated measurements (${timeCols.joinToString { it.name }}) as within-subjects factor. The between-subjects effect was ${if (betweenMain.p < 0.05) "significant" else "non-significant"}, F(${StatsMath.formatNumber(betweenMain.df, 0)}, ${StatsMath.formatNumber(mixedResult.betweenRows[1].df, 0)}) = ${StatsMath.formatNumber(betweenMain.f)}, p ${StatsMath.formatPValue(betweenMain.p)}, ηp² = ${StatsMath.formatNumber(betweenMain.etaSqP)}. The Time main effect yielded F(${StatsMath.formatNumber(timeMain.df, 0)}, ${StatsMath.formatNumber(mixedResult.withinRows.last().df, 0)}) = ${StatsMath.formatNumber(timeMain.f)}, p ${StatsMath.formatPValue(timeMain.p)}, ηp² = ${StatsMath.formatNumber(timeMain.etaSqP)}. The ${factorCol.name} × Time interaction was ${if (interMain.p < 0.05) "statistically significant" else "non-significant"}, F(${StatsMath.formatNumber(interMain.df, 0)}, ${StatsMath.formatNumber(mixedResult.withinRows.last().df, 0)}) = ${StatsMath.formatNumber(interMain.f)}, p ${StatsMath.formatPValue(interMain.p)}, ηp² = ${StatsMath.formatNumber(interMain.etaSqP)}."

                        // APA Table 3a: Between-Subjects Effects
                        val betweenCols = listOf(
                            TableColumn("Source", width = 140),
                            TableColumn("Type III SS", width = 90),
                            TableColumn("df", width = 50, isSymbol = true),
                            TableColumn("MS", width = 85, isSymbol = true),
                            TableColumn("F", width = 75, isSymbol = true),
                            TableColumn("p", width = 75, isSymbol = true),
                            TableColumn("Partial η²", width = 85, isSymbol = true)
                        )

                        val betweenData = mixedResult.betweenRows.map { row ->
                            listOf(
                                row.source,
                                StatsMath.formatNumber(row.ss),
                                StatsMath.formatNumber(row.df, 0),
                                StatsMath.formatNumber(row.ms),
                                if (row.f.isNaN()) "—" else StatsMath.formatNumber(row.f),
                                if (row.p.isNaN()) "—" else StatsMath.formatPValue(row.p),
                                if (row.etaSqP.isNaN()) "—" else StatsMath.formatNumber(row.etaSqP)
                            )
                        }

                        item {
                            ApaTable(
                                tableNumber = "Table 3a",
                                tableTitle = "Mixed ANOVA: Tests of Between-Subjects Effects",
                                columns = betweenCols,
                                rows = betweenData,
                                note = "Between-subjects factor: ${factorCol.name}."
                            )
                        }

                        // APA Table 3b: Within-Subjects Effects & Interaction
                        val withinCols = listOf(
                            TableColumn("Source", width = 150),
                            TableColumn("Type III SS", width = 90),
                            TableColumn("df", width = 50, isSymbol = true),
                            TableColumn("MS", width = 85, isSymbol = true),
                            TableColumn("F", width = 75, isSymbol = true),
                            TableColumn("p", width = 75, isSymbol = true),
                            TableColumn("Partial η²", width = 85, isSymbol = true)
                        )

                        val withinData = mixedResult.withinRows.map { row ->
                            listOf(
                                row.source,
                                StatsMath.formatNumber(row.ss),
                                StatsMath.formatNumber(row.df, 0),
                                StatsMath.formatNumber(row.ms),
                                if (row.f.isNaN()) "—" else StatsMath.formatNumber(row.f),
                                if (row.p.isNaN()) "—" else StatsMath.formatPValue(row.p),
                                if (row.etaSqP.isNaN()) "—" else StatsMath.formatNumber(row.etaSqP)
                            )
                        }

                        item {
                            ApaTable(
                                tableNumber = "Table 3b",
                                tableTitle = "Mixed ANOVA: Tests of Within-Subjects Effects and Interaction",
                                columns = withinCols,
                                rows = withinData,
                                note = "Mauchly's Test of Sphericity: W = ${StatsMath.formatNumber(mixedResult.mauchlyW)}, p = ${StatsMath.formatNumber(mixedResult.mauchlyP)}, Greenhouse-Geisser ε = ${StatsMath.formatNumber(mixedResult.greenhouseGeisserEps)}.",
                                inTextReport = narrative
                            )
                        }

                        item {
                            MixedAnovaProfilePlot(result = mixedResult)
                        }
                    } else {
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = LuxuryGreenContainer.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(
                                        text = "Mixed ANOVA Setup",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = LuxuryDarkGreen
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Please select a Between-Subjects Factor (e.g. Group, Condition) and at least 2 Within-Subjects Repeated Measures.",
                                        fontSize = 12.5.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // ==========================================
                // 3: ANCOVA (ANALYSIS OF COVARIANCE)
                // ==========================================
                3 -> {
                    val dvCol = dataset.columns.find { it.id == selectedDvId }
                    val factorCol = dataset.columns.find { it.id == selectedFactorId }
                    val covCol = dataset.columns.find { it.id == selectedCovariateId }

                    if (dvCol != null && factorCol != null && covCol != null) {
                        val n = minOf(dvCol.values.size, factorCol.values.size, covCol.values.size)
                        val validY = mutableListOf<Double>()
                        val validG = mutableListOf<String>()
                        val validCov = mutableListOf<Double>()

                        for (i in 0 until n) {
                            val yVal = dvCol.values[i].toDoubleOrNull()
                            val gVal = factorCol.values[i].trim()
                            val cVal = covCol.values[i].toDoubleOrNull()
                            if (yVal != null && gVal.isNotBlank() && cVal != null) {
                                validY.add(yVal)
                                validG.add(gVal)
                                validCov.add(cVal)
                            }
                        }

                        if (validY.size >= 4 && validG.distinct().size >= 2) {
                            val ancovaResult = StatsMath.ancova(
                                y = validY,
                                factor = validG,
                                covariate = validCov,
                                dvName = dvCol.name,
                                factorName = factorCol.name,
                                covariateName = covCol.name
                            )

                            val covRow = ancovaResult.rows[0]
                            val factRow = ancovaResult.rows[1]

                            val narrative = "An analysis of covariance (ANCOVA) was conducted on ${dvCol.name} across levels of ${factorCol.name}, controlling for ${covCol.name}. The covariate ${covCol.name} was ${if (covRow.p < 0.05) "significantly" else "not significantly"} related to ${dvCol.name}, F(1, ${StatsMath.formatNumber(ancovaResult.rows[2].df, 0)}) = ${StatsMath.formatNumber(covRow.f)}, p ${StatsMath.formatPValue(covRow.p)}, partial η² = ${StatsMath.formatNumber(covRow.partialEtaSq)}. After controlling for ${covCol.name}, the main effect of ${factorCol.name} was ${if (factRow.p < 0.05) "statistically significant" else "non-significant"}, F(${StatsMath.formatNumber(factRow.df, 0)}, ${StatsMath.formatNumber(ancovaResult.rows[2].df, 0)}) = ${StatsMath.formatNumber(factRow.f)}, p ${StatsMath.formatPValue(factRow.p)}, partial η² = ${StatsMath.formatNumber(factRow.partialEtaSq)}."

                            val ancovaCols = listOf(
                                TableColumn("Source", width = 140),
                                TableColumn("Type III SS", width = 90),
                                TableColumn("df", width = 50, isSymbol = true),
                                TableColumn("MS", width = 85, isSymbol = true),
                                TableColumn("F", width = 75, isSymbol = true),
                                TableColumn("p", width = 75, isSymbol = true),
                                TableColumn("Partial η²", width = 85, isSymbol = true)
                            )

                            val ancovaRows = ancovaResult.rows.map { row ->
                                listOf(
                                    row.source,
                                    StatsMath.formatNumber(row.ss),
                                    StatsMath.formatNumber(row.df, 0),
                                    StatsMath.formatNumber(row.ms),
                                    if (row.f.isNaN()) "—" else StatsMath.formatNumber(row.f),
                                    if (row.p.isNaN()) "—" else StatsMath.formatPValue(row.p),
                                    if (row.partialEtaSq.isNaN()) "—" else StatsMath.formatNumber(row.partialEtaSq)
                                )
                            }

                            item {
                                ApaTable(
                                    tableNumber = "Table 3",
                                    tableTitle = "Analysis of Covariance (ANCOVA) Summary for ${dvCol.name}",
                                    columns = ancovaCols,
                                    rows = ancovaRows,
                                    note = "Covariate evaluated at value = ${StatsMath.formatNumber(ancovaResult.grandMeanCov)}. Model R² = ${StatsMath.formatNumber(ancovaResult.rSquared)}.",
                                    inTextReport = narrative
                                )
                            }

                            // Adjusted Means Table
                            item {
                                val adjCols = listOf(
                                    TableColumn("Group", width = 110),
                                    TableColumn("n", width = 50, isSymbol = true),
                                    TableColumn("Observed M", width = 90),
                                    TableColumn("Adjusted M", width = 90),
                                    TableColumn("SE", width = 75, isSymbol = true),
                                    TableColumn("95% CI Lower", width = 95),
                                    TableColumn("95% CI Upper", width = 95)
                                )
                                val adjRows = ancovaResult.adjustedMeans.map { am ->
                                    listOf(
                                        am.group,
                                        am.n.toString(),
                                        StatsMath.formatNumber(am.unadjustedMean),
                                        StatsMath.formatNumber(am.adjustedMean),
                                        StatsMath.formatNumber(am.se),
                                        StatsMath.formatNumber(am.ciL),
                                        StatsMath.formatNumber(am.ciU)
                                    )
                                }

                                ApaTable(
                                    tableNumber = "Table 3b",
                                    tableTitle = "Observed and Estimated Marginal (Adjusted) Means for ${factorCol.name}",
                                    columns = adjCols,
                                    rows = adjRows,
                                    note = "Adjusted means control for the baseline covariate ${covCol.name}."
                                )
                            }

                            // ANCOVA Adjusted Plot
                            item {
                                AncovaAdjustedPlot(result = ancovaResult)
                            }
                        } else {
                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = LuxuryGreenContainer.copy(alpha = 0.5f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text("Please ensure the factor has at least 2 distinct categories and valid covariate observations.", fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
