package com.example.ui.components

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DataColumn
import com.example.model.Dataset
import com.example.model.VariableType
import com.example.ui.theme.JamoviTeal
import com.example.ui.theme.JamoviTealContainer
import com.example.util.SpreadsheetImporter

@Composable
fun DataGrid(
    dataset: Dataset,
    onCellEdited: (columnIndex: Int, rowIndex: Int, newValue: String) -> Unit,
    onAddRow: () -> Unit,
    onAddColumn: (name: String, type: VariableType) -> Unit,
    onUpdateColumnType: (columnIndex: Int, newType: VariableType) -> Unit,
    onRenameColumn: (columnIndex: Int, newName: String) -> Unit,
    onDeleteColumn: (columnIndex: Int) -> Unit,
    onSelectSampleDataset: (String) -> Unit,
    onDatasetImported: (Dataset) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val hScroll = rememberScrollState()

    var editCellTarget by remember { mutableStateOf<Triple<Int, Int, String>?>(null) }
    var selectedColForEdit by remember { mutableStateOf<Pair<Int, DataColumn>?>(null) }
    var showAddColDialog by remember { mutableStateOf(false) }
    var showSampleDialog by remember { mutableStateOf(false) }

    // File picker launcher for XLSX & CSV
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val imported = SpreadsheetImporter.importFile(context, uri)
            if (imported != null && imported.columns.isNotEmpty()) {
                onDatasetImported(imported)
                Toast.makeText(context, "Loaded ${imported.title} (${imported.rowCount} rows)", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Failed to parse file. Ensure it is a valid .xlsx or .csv", Toast.LENGTH_LONG).show()
            }
        }
    }

    val isDark = isSystemInDarkTheme()
    val gridHeaderBg = if (isDark) Color(0xFF1E293B) else Color(0xFFE2E8F0)
    val gridHeaderBorder = if (isDark) Color(0xFF334155) else Color(0xFFCBD5E1)
    val gridHeaderTextColor = if (isDark) Color(0xFFF8FAFC) else Color(0xFF0F172A)
    val gridRowBgEven = if (isDark) Color(0xFF0F172A) else Color.White
    val gridRowBgOdd = if (isDark) Color(0xFF162032) else Color(0xFFF8FAFC)
    val gridRowBorder = if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0)
    val gridCellTextColor = if (isDark) Color(0xFFF8FAFC) else Color(0xFF0F172A)
    val gridIndexBg = if (isDark) Color(0xFF1E293B) else Color(0xFFF1F5F9)
    val gridIndexTextColor = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Dataset Toolbar with Upload .xlsx option
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 1.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = dataset.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${dataset.rowCount} rows × ${dataset.columns.size} variables • Tap column header to change type (Scale/Nominal/Ordinal)",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Upload XLSX / CSV Button
                    FilledTonalButton(
                        onClick = {
                            filePickerLauncher.launch(
                                arrayOf(
                                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                    "application/vnd.ms-excel",
                                    "text/csv",
                                    "text/comma-separated-values",
                                    "text/tab-separated-values",
                                    "text/plain",
                                    "*/*"
                                )
                            )
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(Icons.Default.UploadFile, contentDescription = "Upload XLSX", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Upload xlsx", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                    }

                    // Sample Datasets
                    OutlinedButton(
                        onClick = { showSampleDialog = true },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(Icons.Default.Dataset, contentDescription = "Samples", modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("Samples", fontSize = 11.5.sp)
                    }

                    // Add Column
                    OutlinedButton(
                        onClick = { showAddColDialog = true },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add Col", modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("+Col", fontSize = 11.5.sp)
                    }

                    // Add Row
                    Button(
                        onClick = onAddRow,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = JamoviTeal),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add Row", modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("+Row", fontSize = 11.5.sp)
                    }
                }
            }
        }

        // Spreadsheet Table
        Box(
            modifier = Modifier
                .fillMaxSize()
                .horizontalScroll(hScroll)
        ) {
            Column {
                // Column Headers
                Row(
                    modifier = Modifier
                        .background(gridHeaderBg)
                        .border(0.5.dp, gridHeaderBorder)
                ) {
                    // Row index corner box
                    Box(
                        modifier = Modifier
                            .width(44.dp)
                            .height(38.dp)
                            .background(gridIndexBg)
                            .border(0.5.dp, gridHeaderBorder),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("#", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = gridIndexTextColor)
                    }

                    // Column headers - Clickable to change type!
                    dataset.columns.forEachIndexed { colIdx, col ->
                        Box(
                            modifier = Modifier
                                .width(125.dp)
                                .height(38.dp)
                                .background(gridHeaderBg)
                                .border(0.5.dp, gridHeaderBorder)
                                .clickable {
                                    selectedColForEdit = Pair(colIdx, col)
                                }
                                .padding(horizontal = 6.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(col.type.symbol, fontSize = 13.sp)
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text(
                                        text = col.name,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = gridHeaderTextColor
                                    )
                                }
                                Icon(
                                    Icons.Default.ArrowDropDown,
                                    contentDescription = "Edit Type",
                                    tint = gridHeaderTextColor.copy(alpha = 0.6f),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                // Grid Body Rows
                LazyColumn(modifier = Modifier.fillMaxHeight()) {
                    items(dataset.rowCount) { rowIndex ->
                        val rowBg = if (rowIndex % 2 == 1) gridRowBgOdd else gridRowBgEven
                        Row(
                            modifier = Modifier
                                .background(rowBg)
                                .border(0.5.dp, gridRowBorder)
                        ) {
                            // Row Number Cell
                            Box(
                                modifier = Modifier
                                    .width(44.dp)
                                    .height(32.dp)
                                    .background(gridIndexBg)
                                    .border(0.5.dp, gridRowBorder),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("${rowIndex + 1}", fontSize = 11.sp, color = gridIndexTextColor)
                            }

                            // Value Cells
                            dataset.columns.forEachIndexed { colIndex, col ->
                                val cellVal = col.values.getOrElse(rowIndex) { "" }
                                Box(
                                    modifier = Modifier
                                        .width(125.dp)
                                        .height(32.dp)
                                        .border(0.5.dp, gridRowBorder)
                                        .clickable {
                                            editCellTarget = Triple(colIndex, rowIndex, cellVal)
                                        }
                                        .padding(horizontal = 8.dp),
                                    contentAlignment = Alignment.CenterStart
                                ) {
                                    Text(
                                        text = cellVal,
                                        fontSize = 12.sp,
                                        color = if (cellVal.isEmpty()) Color.Gray else gridCellTextColor
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Column Variable Type / Rename Dialog
    selectedColForEdit?.let { (colIdx, col) ->
        var editedName by remember { mutableStateOf(col.name) }
        var currentType by remember { mutableStateOf(col.type) }

        AlertDialog(
            onDismissRequest = { selectedColForEdit = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Tune, contentDescription = null, tint = JamoviTeal)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Variable Settings", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editedName,
                        onValueChange = { editedName = it },
                        label = { Text("Variable Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("Measurement Type:", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                    listOf(VariableType.SCALE, VariableType.NOMINAL, VariableType.ORDINAL).forEach { vType ->
                        Surface(
                            onClick = { currentType = vType },
                            shape = MaterialTheme.shapes.small,
                            color = if (currentType == vType) JamoviTealContainer.copy(alpha = 0.5f) else Color.Transparent,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                RadioButton(selected = currentType == vType, onClick = { currentType = vType })
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text("${vType.symbol} ${vType.label}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(vType.description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (dataset.columns.size > 1) {
                        TextButton(
                            onClick = {
                                onDeleteColumn(colIdx)
                                selectedColForEdit = null
                            },
                            colors = ButtonDefaults.textButtonColors(contentColor = Color.Red)
                        ) {
                            Text("Delete")
                        }
                    }

                    Button(
                        onClick = {
                            if (editedName.isNotBlank() && editedName != col.name) {
                                onRenameColumn(colIdx, editedName)
                            }
                            if (currentType != col.type) {
                                onUpdateColumnType(colIdx, currentType)
                            }
                            selectedColForEdit = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = JamoviTeal)
                    ) {
                        Text("Apply")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedColForEdit = null }) { Text("Cancel") }
            }
        )
    }

    // Edit Cell Dialog
    editCellTarget?.let { (colIdx, rowIdx, currentVal) ->
        var inputVal by remember { mutableStateOf(currentVal) }
        val colName = dataset.columns[colIdx].name
        AlertDialog(
            onDismissRequest = { editCellTarget = null },
            title = { Text("Edit Cell ($colName, Row ${rowIdx + 1})", fontSize = 15.sp) },
            text = {
                OutlinedTextField(
                    value = inputVal,
                    onValueChange = { inputVal = it },
                    label = { Text("Value") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCellEdited(colIdx, rowIdx, inputVal)
                        editCellTarget = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = JamoviTeal)
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { editCellTarget = null }) { Text("Cancel") }
            }
        )
    }

    // Add Column Dialog with Scale, Nominal, Ordinal
    if (showAddColDialog) {
        var colName by remember { mutableStateOf("var_${dataset.columns.size + 1}") }
        var selectedType by remember { mutableStateOf(VariableType.SCALE) }

        AlertDialog(
            onDismissRequest = { showAddColDialog = false },
            title = { Text("Add Variable / Column", fontSize = 15.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = colName,
                        onValueChange = { colName = it },
                        label = { Text("Variable Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Measurement Type (Scale, Nominal, Ordinal)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    listOf(VariableType.SCALE, VariableType.NOMINAL, VariableType.ORDINAL).forEach { vType ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedType = vType }
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(selected = selectedType == vType, onClick = { selectedType = vType })
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("${vType.symbol} ${vType.label} - ${vType.description}", fontSize = 12.sp)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (colName.isNotBlank()) {
                            onAddColumn(colName.trim(), selectedType)
                        }
                        showAddColDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = JamoviTeal)
                ) {
                    Text("Add")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddColDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Sample Datasets Dialog
    if (showSampleDialog) {
        AlertDialog(
            onDismissRequest = { showSampleDialog = false },
            title = { Text("Load Built-in Sample Dataset", fontSize = 15.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SampleOptionItem(
                        title = "Student Exam & Wellbeing",
                        description = "N=20 students: Scale (exam_score, anxiety, study_hours), Nominal (group), Ordinal (grade_level).",
                        onClick = {
                            onSelectSampleDataset("student")
                            showSampleDialog = false
                        }
                    )
                    SampleOptionItem(
                        title = "Big Five Psychometric Scale",
                        description = "N=15 item responses: Extraversion, Neuroticism, Openness for reliability & PCA.",
                        onClick = {
                            onSelectSampleDataset("psychometric")
                            showSampleDialog = false
                        }
                    )
                    SampleOptionItem(
                        title = "Clinical Pharmacotherapy Trial (Repeated)",
                        description = "N=12 patients: Drug A, Drug B, Placebo, baseline, endpoint, and follow-up scores for Mixed ANOVA.",
                        onClick = {
                            onSelectSampleDataset("clinical")
                            showSampleDialog = false
                        }
                    )
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showSampleDialog = false }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun SampleOptionItem(
    title: String,
    description: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = MaterialTheme.shapes.small,
        color = JamoviTealContainer.copy(alpha = 0.5f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = JamoviTeal)
            Spacer(modifier = Modifier.height(2.dp))
            Text(description, fontSize = 11.5.sp, color = Color(0xFF334155))
        }
    }
}
