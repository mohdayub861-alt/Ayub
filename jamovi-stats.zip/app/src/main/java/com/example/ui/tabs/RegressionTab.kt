package com.example.ui.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Dataset
import com.example.stats.StatsMath
import com.example.ui.components.*
import com.example.ui.theme.LuxuryDarkGreen
import com.example.ui.theme.LuxuryGreenContainer

@Composable
fun RegressionTab(
    dataset: Dataset,
    modifier: Modifier = Modifier
) {
    var regType by remember { mutableStateOf("Linear") } // "Linear", "Hierarchical", "Stepwise", "Logistic"
    val continuousCols = dataset.continuousColumns()

    var selectedDvId by remember(dataset) {
        mutableStateOf(continuousCols.firstOrNull()?.id)
    }
    var selectedPredIds by remember(dataset) {
        mutableStateOf(continuousCols.drop(1).take(2).map { it.id }.toSet())
    }

    val availablePredictors = continuousCols.filter { it.id != selectedDvId }
    val selectedPredictors = availablePredictors.filter { selectedPredIds.contains(it.id) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Linear", "Stepwise", "Hierarchical", "Logistic").forEach { t ->
                            FilterChip(
                                selected = regType == t,
                                onClick = { regType = t },
                                label = { Text("$t Regression", fontWeight = if (regType == t) FontWeight.Bold else FontWeight.Normal) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = LuxuryDarkGreen,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    SingleVariableSelector(
                        title = "Dependent Variable (Outcome):",
                        availableColumns = continuousCols,
                        selectedId = selectedDvId,
                        onSelectColumn = { selectedDvId = it }
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    VariableChipRow(
                        title = if (regType == "Stepwise") "Candidate Predictor Pool (Stepwise Entry):" else "Predictors / Covariates:",
                        availableColumns = availablePredictors,
                        selectedIds = selectedPredIds,
                        onToggleColumn = { pId ->
                            selectedPredIds = if (selectedPredIds.contains(pId)) {
                                if (selectedPredIds.size > 1) selectedPredIds - pId else selectedPredIds
                            } else {
                                selectedPredIds + pId
                            }
                        }
                    )
                }
            }
        }

        // Calculation & APA Output
        val dvCol = dataset.columns.find { it.id == selectedDvId }
        if (dvCol != null && selectedPredictors.isNotEmpty()) {
            val y = dvCol.getValidDoubles()
            val xList = selectedPredictors.map { it.getValidDoubles() }

            if (regType == "Stepwise") {
                // ==========================================
                // STEPWISE REGRESSION
                // ==========================================
                val stepwiseRes = StatsMath.stepwiseRegression(
                    candidateMatrices = xList,
                    y = y,
                    candidateNames = selectedPredictors.map { it.name },
                    dvName = dvCol.name
                )

                // Narrative
                val stepsNarrative = buildString {
                    append("A stepwise multiple regression analysis was conducted with ${dvCol.name} as the dependent variable and ${selectedPredictors.joinToString { it.name }} as candidate predictors. ")
                    if (stepwiseRes.steps.isNotEmpty()) {
                        val finalStep = stepwiseRes.steps.last()
                        append("The stepwise algorithm terminated at Model ${finalStep.stepNumber} with ${finalStep.currentVariables.joinToString { it }} retained in the equation. ")
                        append("The final model accounted for a significant proportion of the variance in ${dvCol.name}, F(${StatsMath.formatNumber(stepwiseRes.finalDf1, 0)}, ${StatsMath.formatNumber(stepwiseRes.finalDf2, 0)}) = ${StatsMath.formatNumber(stepwiseRes.finalF)}, p ${StatsMath.formatPValue(stepwiseRes.finalP)}, R² = ${StatsMath.formatNumber(stepwiseRes.finalRSquared)} (Adj. R² = ${StatsMath.formatNumber(stepwiseRes.finalAdjRSquared)}). ")
                    }
                }

                // Table 6a: Stepwise Model Summary
                item {
                    val stepCols = listOf(
                        TableColumn("Model Step", width = 85),
                        TableColumn("Variable Entered", width = 130),
                        TableColumn("R", width = 75, isSymbol = true),
                        TableColumn("R²", width = 75, isSymbol = true),
                        TableColumn("ΔR²", width = 75, isSymbol = true),
                        TableColumn("F Change", width = 80),
                        TableColumn("df1", width = 50, isSymbol = true),
                        TableColumn("df2", width = 50, isSymbol = true),
                        TableColumn("Sig. F Change", width = 95)
                    )

                    val stepRows = stepwiseRes.steps.map { s ->
                        listOf(
                            s.stepNumber.toString(),
                            s.variable,
                            StatsMath.formatNumber(s.r),
                            StatsMath.formatNumber(s.rSquared),
                            StatsMath.formatNumber(s.deltaRSquared),
                            StatsMath.formatNumber(s.fChange),
                            StatsMath.formatNumber(s.df1, 0),
                            StatsMath.formatNumber(s.df2, 0),
                            StatsMath.formatPValue(s.pChange)
                        )
                    }

                    ApaTable(
                        tableNumber = "Table 6a",
                        tableTitle = "Stepwise Multiple Regression Model Summary for ${dvCol.name}",
                        columns = stepCols,
                        rows = stepRows,
                        note = "Criteria for stepwise entry: Probability of F-to-enter <= 0.05. Dependent variable: ${dvCol.name}.",
                        inTextReport = stepsNarrative
                    )
                }

                // Table 6b: Coefficients of Final Model
                item {
                    val coeffCols = listOf(
                        TableColumn("Predictor", width = 120),
                        TableColumn("B", width = 75, isSymbol = true),
                        TableColumn("SE B", width = 75),
                        TableColumn("β", width = 75, isSymbol = true),
                        TableColumn("t", width = 70, isSymbol = true),
                        TableColumn("p", width = 75, isSymbol = true),
                        TableColumn("95% CI Lower", width = 95),
                        TableColumn("95% CI Upper", width = 95),
                        TableColumn("VIF", width = 70)
                    )

                    val coeffRows = stepwiseRes.finalModelCoefficients.map { c ->
                        listOf(
                            c.term,
                            StatsMath.formatNumber(c.b),
                            StatsMath.formatNumber(c.se),
                            if (c.beta == 0.0) "—" else StatsMath.formatNumber(c.beta),
                            StatsMath.formatNumber(c.t),
                            StatsMath.formatPValue(c.p),
                            StatsMath.formatNumber(c.ciL),
                            StatsMath.formatNumber(c.ciU),
                            StatsMath.formatNumber(c.vif)
                        )
                    }

                    ApaTable(
                        tableNumber = "Table 6b",
                        tableTitle = "Coefficients for Final Stepwise Regression Model",
                        columns = coeffCols,
                        rows = coeffRows,
                        note = "B = unstandardized regression weight; SE B = standard error; β = standardized coefficient; VIF = variance inflation factor."
                    )
                }

                // Table 6c: Excluded Variables
                if (stepwiseRes.excludedVariables.isNotEmpty()) {
                    item {
                        val exclCols = listOf(
                            TableColumn("Excluded Variable", width = 130),
                            TableColumn("Beta In", width = 80),
                            TableColumn("t", width = 70, isSymbol = true),
                            TableColumn("p", width = 75, isSymbol = true),
                            TableColumn("Partial Cor.", width = 85),
                            TableColumn("Tolerance", width = 80)
                        )

                        val exclRows = stepwiseRes.excludedVariables.map { ev ->
                            listOf(
                                ev.variable,
                                StatsMath.formatNumber(ev.betaIn),
                                StatsMath.formatNumber(ev.t),
                                StatsMath.formatPValue(ev.p),
                                StatsMath.formatNumber(ev.partialCor),
                                StatsMath.formatNumber(ev.tolerance)
                            )
                        }

                        ApaTable(
                            tableNumber = "Table 6c",
                            tableTitle = "Variables Excluded from Final Model",
                            columns = exclCols,
                            rows = exclRows,
                            note = "Variables not meeting entry threshold p < 0.05 at termination."
                        )
                    }
                }

                // Scatterplot with strongest predictor
                item {
                    val firstX = selectedPredictors.first()
                    RegressionScatterPlot(
                        x = firstX.getValidDoubles(),
                        y = y,
                        xLabel = firstX.name,
                        yLabel = dvCol.name
                    )
                }
            } else {
                // ==========================================
                // LINEAR / HIERARCHICAL / LOGISTIC
                // ==========================================
                val regResult = StatsMath.multipleRegression(xList, y, selectedPredictors.map { it.name })

                item {
                    // Table 6a: Model Summary
                    val modelCols = listOf(
                        TableColumn("Model", width = 80),
                        TableColumn("R", width = 75, isSymbol = true),
                        TableColumn("R²", width = 75, isSymbol = true),
                        TableColumn("Adj. R²", width = 80, isSymbol = true),
                        TableColumn("SE of Est.", width = 85),
                        TableColumn("F", width = 75, isSymbol = true),
                        TableColumn("df1", width = 50, isSymbol = true),
                        TableColumn("df2", width = 50, isSymbol = true),
                        TableColumn("p", width = 75, isSymbol = true)
                    )
                    val modelRows = listOf(
                        listOf(
                            "1",
                            StatsMath.formatNumber(regResult.r),
                            StatsMath.formatNumber(regResult.rSquared),
                            StatsMath.formatNumber(regResult.adjRSquared),
                            StatsMath.formatNumber(regResult.seModel),
                            StatsMath.formatNumber(regResult.fStat),
                            StatsMath.formatNumber(regResult.df1, 0),
                            StatsMath.formatNumber(regResult.df2, 0),
                            StatsMath.formatPValue(regResult.pModel)
                        )
                    )

                    ApaTable(
                        tableNumber = "Table 6a",
                        tableTitle = "Multiple Regression Model Fit Summary for ${dvCol.name}",
                        columns = modelCols,
                        rows = modelRows,
                        note = "Predictors: ${selectedPredictors.joinToString(", ") { it.name }}."
                    )
                }

                item {
                    // Table 6b: Coefficients
                    val coeffCols = listOf(
                        TableColumn("Predictor", width = 120),
                        TableColumn("B", width = 75, isSymbol = true),
                        TableColumn("SE B", width = 75),
                        TableColumn("β", width = 75, isSymbol = true),
                        TableColumn("t", width = 70, isSymbol = true),
                        TableColumn("p", width = 75, isSymbol = true),
                        TableColumn("95% CI Lower", width = 95),
                        TableColumn("95% CI Upper", width = 95),
                        TableColumn("VIF", width = 70)
                    )

                    val coeffRows = regResult.coefficients.map { c ->
                        listOf(
                            c.term,
                            StatsMath.formatNumber(c.b),
                            StatsMath.formatNumber(c.se),
                            if (c.beta == 0.0) "—" else StatsMath.formatNumber(c.beta),
                            StatsMath.formatNumber(c.t),
                            StatsMath.formatPValue(c.p),
                            StatsMath.formatNumber(c.ciL),
                            StatsMath.formatNumber(c.ciU),
                            StatsMath.formatNumber(c.vif)
                        )
                    }

                    val primaryPred = regResult.coefficients.getOrNull(1)
                    val narrative = if (primaryPred != null) {
                        "A multiple linear regression was calculated to predict ${dvCol.name} based on ${selectedPredictors.joinToString { it.name }}. A significant regression equation was found (F(${StatsMath.formatNumber(regResult.df1, 0)}, ${StatsMath.formatNumber(regResult.df2, 0)}) = ${StatsMath.formatNumber(regResult.fStat)}, p ${StatsMath.formatPValue(regResult.pModel)}), with an R² of ${StatsMath.formatNumber(regResult.rSquared)}. Specifically, ${primaryPred.term} was a significant predictor (B = ${StatsMath.formatNumber(primaryPred.b)}, β = ${StatsMath.formatNumber(primaryPred.beta)}, t = ${StatsMath.formatNumber(primaryPred.t)}, p ${StatsMath.formatPValue(primaryPred.p)})."
                    } else null

                    ApaTable(
                        tableNumber = "Table 6b",
                        tableTitle = "Regression Coefficients and Collinearity Statistics",
                        columns = coeffCols,
                        rows = coeffRows,
                        note = "B = unstandardized regression coefficient; SE B = standard error; β = standardized beta weight; VIF = variance inflation factor.",
                        inTextReport = narrative
                    )
                }

                // Scatterplot with fitted line
                item {
                    val firstX = selectedPredictors.first()
                    RegressionScatterPlot(
                        x = firstX.getValidDoubles(),
                        y = y,
                        xLabel = firstX.name,
                        yLabel = dvCol.name
                    )
                }
            }
        }
    }
}
