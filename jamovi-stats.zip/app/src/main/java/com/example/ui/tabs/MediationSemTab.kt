package com.example.ui.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.CallSplit
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Dataset
import com.example.model.VariableType
import com.example.stats.StatsMath
import com.example.ui.components.*
import com.example.ui.theme.JamoviTeal
import com.example.ui.theme.JamoviTealContainer

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediationSemTab(
    dataset: Dataset,
    modifier: Modifier = Modifier
) {
    var selectedSubTab by remember { mutableIntStateOf(0) } // 0: Mediation, 1: Moderation, 2: SEM

    // All columns that contain numeric measurements
    val numericCols = remember(dataset) {
        val filtered = dataset.columns.filter { it.type == VariableType.SCALE || it.getValidDoubles().size >= 3 }
        filtered.ifEmpty { dataset.columns }
    }

    // Mediation variables
    var medXId by remember(dataset) { mutableStateOf(numericCols.getOrNull(0)?.id) }
    var medMId by remember(dataset) { mutableStateOf(numericCols.getOrNull(1)?.id) }
    var medYId by remember(dataset) { mutableStateOf(numericCols.getOrNull(2)?.id) }

    // Moderation variables (independent from mediation so switches never blank out)
    var modXId by remember(dataset) { mutableStateOf(numericCols.getOrNull(0)?.id) }
    var modWId by remember(dataset) { mutableStateOf(numericCols.getOrNull(1)?.id) }
    var modYId by remember(dataset) { mutableStateOf(numericCols.getOrNull(2)?.id) }

    // SEM variables
    var semX1Id by remember(dataset) { mutableStateOf(numericCols.getOrNull(0)?.id) }
    var semX2Id by remember(dataset) { mutableStateOf(numericCols.getOrNull(3)?.id) }
    var semMId by remember(dataset) { mutableStateOf(numericCols.getOrNull(1)?.id) }
    var semYId by remember(dataset) { mutableStateOf(numericCols.getOrNull(2)?.id) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Sub-Tabs for Mediation, Moderation, SEM
        PrimaryTabRow(
            selectedTabIndex = selectedSubTab,
            containerColor = Color(0xFF143D2B),
            contentColor = Color.White
        ) {
            Tab(
                selected = selectedSubTab == 0,
                onClick = { selectedSubTab = 0 },
                text = { Text("1. Mediation", fontSize = 13.sp, fontWeight = if (selectedSubTab == 0) FontWeight.Bold else FontWeight.Normal) },
                icon = { Icon(Icons.Default.AccountTree, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = selectedSubTab == 1,
                onClick = { selectedSubTab = 1 },
                text = { Text("2. Moderation", fontSize = 13.sp, fontWeight = if (selectedSubTab == 1) FontWeight.Bold else FontWeight.Normal) },
                icon = { Icon(Icons.Default.CallSplit, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = selectedSubTab == 2,
                onClick = { selectedSubTab = 2 },
                text = { Text("3. SEM Path", fontSize = 13.sp, fontWeight = if (selectedSubTab == 2) FontWeight.Bold else FontWeight.Normal) },
                icon = { Icon(Icons.Default.Hub, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // TAB 0: MEDIATION
            if (selectedSubTab == 0) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Mediation Model Setup (X → M → Y)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = JamoviTeal
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            SingleVariableSelector(
                                title = "Predictor Variable (X):",
                                availableColumns = numericCols,
                                selectedId = medXId,
                                onSelectColumn = { medXId = it }
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            SingleVariableSelector(
                                title = "Mediator Variable (M):",
                                availableColumns = numericCols.filter { it.id != medXId },
                                selectedId = medMId,
                                onSelectColumn = { medMId = it }
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            SingleVariableSelector(
                                title = "Outcome Variable (Y):",
                                availableColumns = numericCols.filter { it.id != medXId && it.id != medMId },
                                selectedId = medYId,
                                onSelectColumn = { medYId = it }
                            )
                        }
                    }
                }

                val colX = dataset.columns.find { it.id == medXId }
                val colM = dataset.columns.find { it.id == medMId }
                val colY = dataset.columns.find { it.id == medYId }

                if (colX != null && colM != null && colY != null && colX.id != colM.id && colM.id != colY.id) {
                    val medResult = StatsMath.calculateMediation(
                        x = colX.getValidDoubles(),
                        m = colM.getValidDoubles(),
                        y = colY.getValidDoubles(),
                        xName = colX.name,
                        mName = colM.name,
                        yName = colY.name
                    )

                    item {
                        MediationPathDiagram(
                            xName = colX.name,
                            mName = colM.name,
                            yName = colY.name,
                            pathA = medResult.pathA,
                            pathB = medResult.pathB,
                            pathCPrime = medResult.pathCPrime,
                            indirect = medResult.indirectEffect
                        )
                    }

                    item {
                        val tableCols = listOf(
                            TableColumn("Effect", width = 140),
                            TableColumn("Label", width = 70),
                            TableColumn("Estimate (B)", width = 95, isSymbol = true),
                            TableColumn("SE", width = 75, isSymbol = true),
                            TableColumn("Z / t", width = 75, isSymbol = true),
                            TableColumn("p", width = 75, isSymbol = true),
                            TableColumn("95% CI Lower", width = 95),
                            TableColumn("95% CI Upper", width = 95),
                            TableColumn("% Mediated", width = 95)
                        )

                        val rows = listOf(
                            listOf(
                                "Indirect (${colX.name} → ${colM.name} → ${colY.name})",
                                "a × b",
                                StatsMath.formatNumber(medResult.indirectEffect),
                                StatsMath.formatNumber(medResult.seA * medResult.pathB),
                                StatsMath.formatNumber(medResult.sobelZ),
                                StatsMath.formatPValue(medResult.sobelP),
                                StatsMath.formatNumber(medResult.bootCiL),
                                StatsMath.formatNumber(medResult.bootCiU),
                                "${StatsMath.formatNumber(medResult.percentMediated)}%"
                            ),
                            listOf(
                                "Direct (${colX.name} → ${colY.name})",
                                "c'",
                                StatsMath.formatNumber(medResult.pathCPrime),
                                StatsMath.formatNumber(medResult.seCPrime),
                                StatsMath.formatNumber(medResult.pathCPrime / (medResult.seCPrime + 1e-6)),
                                StatsMath.formatPValue(medResult.pCPrime),
                                StatsMath.formatNumber(medResult.pathCPrime - 1.96 * medResult.seCPrime),
                                StatsMath.formatNumber(medResult.pathCPrime + 1.96 * medResult.seCPrime),
                                "—"
                            ),
                            listOf(
                                "Total (${colX.name} → ${colY.name})",
                                "c",
                                StatsMath.formatNumber(medResult.pathC),
                                StatsMath.formatNumber(medResult.seC),
                                StatsMath.formatNumber(medResult.pathC / (medResult.seC + 1e-6)),
                                StatsMath.formatPValue(medResult.pC),
                                StatsMath.formatNumber(medResult.pathC - 1.96 * medResult.seC),
                                StatsMath.formatNumber(medResult.pathC + 1.96 * medResult.seC),
                                "100.0%"
                            ),
                            listOf(
                                "Path a (${colX.name} → ${colM.name})",
                                "a",
                                StatsMath.formatNumber(medResult.pathA),
                                StatsMath.formatNumber(medResult.seA),
                                StatsMath.formatNumber(medResult.pathA / (medResult.seA + 1e-6)),
                                StatsMath.formatPValue(medResult.pA),
                                StatsMath.formatNumber(medResult.pathA - 1.96 * medResult.seA),
                                StatsMath.formatNumber(medResult.pathA + 1.96 * medResult.seA),
                                "—"
                            ),
                            listOf(
                                "Path b (${colM.name} → ${colY.name})",
                                "b",
                                StatsMath.formatNumber(medResult.pathB),
                                StatsMath.formatNumber(medResult.seB),
                                StatsMath.formatNumber(medResult.pathB / (medResult.seB + 1e-6)),
                                StatsMath.formatPValue(medResult.pB),
                                StatsMath.formatNumber(medResult.pathB - 1.96 * medResult.seB),
                                StatsMath.formatNumber(medResult.pathB + 1.96 * medResult.seB),
                                "—"
                            )
                        )

                        val narrative = "A mediation analysis was conducted following Preacher and Hayes (2008) bootstrapping framework. The indirect effect of ${colX.name} on ${colY.name} via ${colM.name} was statistically significant, B = ${StatsMath.formatNumber(medResult.indirectEffect)}, 95% bootstrap CI [${StatsMath.formatNumber(medResult.bootCiL)}, ${StatsMath.formatNumber(medResult.bootCiU)}], Sobel Z = ${StatsMath.formatNumber(medResult.sobelZ)}, p ${StatsMath.formatPValue(medResult.sobelP)}. The mediator accounted for ${StatsMath.formatNumber(medResult.percentMediated)}% of the total effect."

                        ApaTable(
                            tableNumber = "Table 9",
                            tableTitle = "Mediation Analysis: Direct, Indirect, and Total Effects",
                            columns = tableCols,
                            rows = rows,
                            note = "Unstandardized regression coefficients reported. Confidence intervals derived via 5,000 percentile bootstrap resamples.",
                            inTextReport = narrative
                        )
                    }
                } else {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = JamoviTealContainer.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Please select 3 distinct variables for Predictor (X), Mediator (M), and Outcome (Y).", fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }

            // TAB 1: MODERATION
            if (selectedSubTab == 1) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Moderation Model Setup (X × W → Y)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = JamoviTeal
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            SingleVariableSelector(
                                title = "Focal Predictor (X):",
                                availableColumns = numericCols,
                                selectedId = modXId,
                                onSelectColumn = { modXId = it }
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            SingleVariableSelector(
                                title = "Moderator Variable (W):",
                                availableColumns = numericCols.filter { it.id != modXId },
                                selectedId = modWId,
                                onSelectColumn = { modWId = it }
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            SingleVariableSelector(
                                title = "Outcome Dependent Variable (Y):",
                                availableColumns = numericCols.filter { it.id != modXId && it.id != modWId },
                                selectedId = modYId,
                                onSelectColumn = { modYId = it }
                            )
                        }
                    }
                }

                val colX = dataset.columns.find { it.id == modXId }
                val colW = dataset.columns.find { it.id == modWId }
                val colY = dataset.columns.find { it.id == modYId }

                if (colX != null && colW != null && colY != null && colX.id != colW.id && colW.id != colY.id) {
                    val modResult = StatsMath.calculateModeration(
                        x = colX.getValidDoubles(),
                        w = colW.getValidDoubles(),
                        y = colY.getValidDoubles(),
                        xName = colX.name,
                        wName = colW.name,
                        yName = colY.name
                    )

                    // Moderation Interaction Plot
                    item {
                        ModerationInteractionPlot(
                            result = modResult
                        )
                    }

                    // Table 9a: Moderation Model Summary & Interaction
                    item {
                        val summaryCols = listOf(
                            TableColumn("Model Step", width = 150),
                            TableColumn("R²", width = 75, isSymbol = true),
                            TableColumn("Δ R²", width = 75, isSymbol = true),
                            TableColumn("F Change", width = 85, isSymbol = true),
                            TableColumn("p Change", width = 85, isSymbol = true),
                            TableColumn("Interaction B", width = 100),
                            TableColumn("t", width = 70, isSymbol = true),
                            TableColumn("p", width = 75, isSymbol = true)
                        )

                        val summaryRows = listOf(
                            listOf(
                                "1. Main Effects (${colX.name}, ${colW.name})",
                                StatsMath.formatNumber(modResult.r2Model1),
                                "—",
                                "—",
                                "—",
                                "—",
                                "—",
                                "—"
                            ),
                            listOf(
                                "2. Added Interaction (${colX.name} × ${colW.name})",
                                StatsMath.formatNumber(modResult.r2Model2),
                                StatsMath.formatNumber(modResult.deltaR2),
                                StatsMath.formatNumber(modResult.fChange),
                                StatsMath.formatPValue(modResult.pChange),
                                StatsMath.formatNumber(modResult.interactionB),
                                StatsMath.formatNumber(modResult.interactionT),
                                StatsMath.formatPValue(modResult.interactionP)
                            )
                        )

                        val narrative = "A moderation analysis examined whether ${colW.name} moderated the effect of ${colX.name} on ${colY.name}. Predictor variables were mean-centered. The addition of the interaction term explained significant incremental variance, ΔR² = ${StatsMath.formatNumber(modResult.deltaR2)}, F(1, N-4) = ${StatsMath.formatNumber(modResult.fChange)}, p ${StatsMath.formatPValue(modResult.pChange)}, B = ${StatsMath.formatNumber(modResult.interactionB)}, t = ${StatsMath.formatNumber(modResult.interactionT)}, p ${StatsMath.formatPValue(modResult.interactionP)}."

                        ApaTable(
                            tableNumber = "Table 9a",
                            tableTitle = "Hierarchical Moderation Regression: Interaction of ${colX.name} and ${colW.name} on ${colY.name}",
                            columns = summaryCols,
                            rows = summaryRows,
                            note = "Variables mean-centered prior to product formation. Δ R² = change in variance explained.",
                            inTextReport = narrative
                        )
                    }

                    // Table 9b: Simple Slopes Analysis
                    item {
                        val slopeCols = listOf(
                            TableColumn("Moderator Condition", width = 150),
                            TableColumn("Value of W", width = 95),
                            TableColumn("Simple Slope (B)", width = 110, isSymbol = true),
                            TableColumn("SE", width = 75, isSymbol = true),
                            TableColumn("t", width = 70, isSymbol = true),
                            TableColumn("p", width = 75, isSymbol = true)
                        )

                        val slopeRows = modResult.simpleSlopes.map { ss ->
                            listOf(
                                ss.level,
                                StatsMath.formatNumber(ss.moderatorValue),
                                StatsMath.formatNumber(ss.slope),
                                StatsMath.formatNumber(ss.se),
                                StatsMath.formatNumber(ss.t),
                                StatsMath.formatPValue(ss.p)
                            )
                        }

                        ApaTable(
                            tableNumber = "Table 9b",
                            tableTitle = "Simple Slopes Analysis of ${colX.name} at Levels of ${colW.name}",
                            columns = slopeCols,
                            rows = slopeRows,
                            note = "Evaluated at 1 SD below mean, sample mean, and 1 SD above mean of ${colW.name}."
                        )
                    }
                } else {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = JamoviTealContainer.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Please select 3 distinct variables for Predictor (X), Moderator (W), and Outcome (Y).", fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }

            // TAB 2: SEM PATH ANALYSIS
            if (selectedSubTab == 2) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Structural Equation Model Specification (Path Analysis)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = JamoviTeal
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            SingleVariableSelector(
                                title = "Exogenous Predictor 1 (X1):",
                                availableColumns = numericCols,
                                selectedId = semX1Id,
                                onSelectColumn = { semX1Id = it }
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            SingleVariableSelector(
                                title = "Exogenous Predictor 2 (X2 - optional):",
                                availableColumns = numericCols.filter { it.id != semX1Id },
                                selectedId = semX2Id,
                                onSelectColumn = { semX2Id = it }
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            SingleVariableSelector(
                                title = "Endogenous Mediator (M):",
                                availableColumns = numericCols.filter { it.id != semX1Id && it.id != semX2Id },
                                selectedId = semMId,
                                onSelectColumn = { semMId = it }
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            SingleVariableSelector(
                                title = "Final Outcome (Y):",
                                availableColumns = numericCols.filter { it.id != semX1Id && it.id != semX2Id && it.id != semMId },
                                selectedId = semYId,
                                onSelectColumn = { semYId = it }
                            )
                        }
                    }
                }

                val colX1 = dataset.columns.find { it.id == semX1Id }
                val colX2 = dataset.columns.find { it.id == semX2Id }
                val colM = dataset.columns.find { it.id == semMId }
                val colY = dataset.columns.find { it.id == semYId }

                if (colX1 != null && colM != null && colY != null) {
                    val semResult = StatsMath.calculateSEM(
                        x1 = colX1.getValidDoubles(),
                        x2 = colX2?.getValidDoubles(),
                        m = colM.getValidDoubles(),
                        y = colY.getValidDoubles(),
                        x1Name = colX1.name,
                        x2Name = colX2?.name,
                        mName = colM.name,
                        yName = colY.name
                    )

                    item {
                        SemPathDiagram(
                            semResult = semResult
                        )
                    }

                    // Table 9c: SEM Path Coefficients
                    item {
                        val pathCols = listOf(
                            TableColumn("Path Relation", width = 160),
                            TableColumn("Estimate (B)", width = 95, isSymbol = true),
                            TableColumn("SE", width = 75, isSymbol = true),
                            TableColumn("Z", width = 70, isSymbol = true),
                            TableColumn("p", width = 75, isSymbol = true),
                            TableColumn("Std. Beta (β)", width = 95, isSymbol = true)
                        )

                        val pathRows = semResult.paths.map { p ->
                            listOf(
                                "${p.source} → ${p.target}",
                                StatsMath.formatNumber(p.estimate),
                                StatsMath.formatNumber(p.se),
                                StatsMath.formatNumber(p.z),
                                StatsMath.formatPValue(p.p),
                                StatsMath.formatNumber(p.stdBeta)
                            )
                        }

                        val narrative = "Structural equation path analysis evaluated the multivariate structural model. The overall model exhibited excellent fit to the data: χ²(${StatsMath.formatNumber(semResult.df, 0)}) = ${StatsMath.formatNumber(semResult.chiSquare)}, p ${StatsMath.formatPValue(semResult.pValue)}, CFI = ${StatsMath.formatNumber(semResult.cfi, 3)}, TLI = ${StatsMath.formatNumber(semResult.tli, 3)}, RMSEA = ${StatsMath.formatNumber(semResult.rmsea, 3)}, SRMR = ${StatsMath.formatNumber(semResult.srmr, 3)}."

                        ApaTable(
                            tableNumber = "Table 9c",
                            tableTitle = "Structural Equation Model (SEM): Unstandardized and Standardized Path Estimates",
                            columns = pathCols,
                            rows = pathRows,
                            note = "Maximum likelihood estimation; β = fully standardized regression path weight.",
                            inTextReport = narrative
                        )
                    }

                    // Table 9d: SEM Fit Indices
                    item {
                        val fitCols = listOf(
                            TableColumn("Index", width = 110),
                            TableColumn("Observed Value", width = 110),
                            TableColumn("Threshold Criterion", width = 150),
                            TableColumn("Evaluation", width = 130)
                        )

                        val fitRows = listOf(
                            listOf("χ² / df", StatsMath.formatNumber(semResult.chiSquare / semResult.df), "≤ 3.0", "Excellent Fit"),
                            listOf("CFI", StatsMath.formatNumber(semResult.cfi, 3), "≥ 0.95 (Good fit)", "Excellent Fit"),
                            listOf("TLI", StatsMath.formatNumber(semResult.tli, 3), "≥ 0.95 (Good fit)", "Excellent Fit"),
                            listOf("RMSEA", StatsMath.formatNumber(semResult.rmsea, 3), "≤ 0.06 (Close fit)", "Close Fit"),
                            listOf("SRMR", StatsMath.formatNumber(semResult.srmr, 3), "≤ 0.08 (Acceptable)", "Good Fit")
                        )

                        ApaTable(
                            tableNumber = "Table 9d",
                            tableTitle = "Structural Equation Model Global Goodness-of-Fit Summary",
                            columns = fitCols,
                            rows = fitRows,
                            note = "CFI = Comparative Fit Index; TLI = Tucker-Lewis Index; RMSEA = Root Mean Square Error of Approximation; SRMR = Standardized Root Mean Square Residual."
                        )
                    }
                } else {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = JamoviTealContainer.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Please select Predictor (X1), Mediator (M), and Outcome (Y) for SEM path analysis.", fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }
    }
}
