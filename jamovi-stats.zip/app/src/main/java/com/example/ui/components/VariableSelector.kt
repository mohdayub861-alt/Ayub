package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DataColumn
import com.example.ui.theme.JamoviTeal
import com.example.ui.theme.JamoviTealContainer

@Composable
fun VariableChipRow(
    title: String,
    availableColumns: List<DataColumn>,
    selectedIds: Set<String>,
    onToggleColumn: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val scroll = rememberScrollState()

    Column(modifier = modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(
            text = title,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scroll),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            availableColumns.forEach { col ->
                val isSelected = selectedIds.contains(col.id)
                FilterChip(
                    selected = isSelected,
                    onClick = { onToggleColumn(col.id) },
                    label = {
                        Text("${col.type.symbol} ${col.name}", fontSize = 12.sp)
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = JamoviTeal,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }
    }
}

@Composable
fun SingleVariableSelector(
    title: String,
    availableColumns: List<DataColumn>,
    selectedId: String?,
    onSelectColumn: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val scroll = rememberScrollState()

    Column(modifier = modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(
            text = title,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scroll),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            availableColumns.forEach { col ->
                val isSelected = selectedId == col.id
                FilterChip(
                    selected = isSelected,
                    onClick = { onSelectColumn(col.id) },
                    label = {
                        Text("${col.type.symbol} ${col.name}", fontSize = 12.sp)
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = JamoviTeal,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }
    }
}
