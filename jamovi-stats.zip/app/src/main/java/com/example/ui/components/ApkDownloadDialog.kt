package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.JamoviTeal
import com.example.ui.theme.JamoviTealContainer

@Composable
fun ApkDownloadDialog(
    onDismiss: () -> Unit,
    fullApaReportText: String
) {
    val context = LocalContext.current
    val devUrl = "https://ais-dev-7fgzvneqyrdroiyceq3gtl-118139412884.asia-east1.run.app"
    val sharedUrl = "https://ais-pre-7fgzvneqyrdroiyceq3gtl-118139412884.asia-east1.run.app"

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Download, contentDescription = "Download", tint = JamoviTeal)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Direct APK Download & Export", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "You can download the compiled APK file directly to install on any Android phone or tablet:",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )

                // Option 1: AI Studio Direct APK Export Instruction
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = JamoviTealContainer.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Android, contentDescription = null, tint = JamoviTeal, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("1. Direct APK Generator", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = JamoviTeal)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "In the AI Studio interface, open the Settings / Project Menu (top right) and click 'Export APK' or 'Download APK / ZIP' to immediately download your standalone .apk installer file.",
                            fontSize = 12.sp,
                            color = Color(0xFF1E293B)
                        )
                    }
                }

                // Option 2: Live App URL & Web link
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF1F5F9),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Link, contentDescription = null, tint = Color(0xFF334155), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("2. Direct Web & Streaming Emulator", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF334155))
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedButton(
                            onClick = {
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(sharedUrl))
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("APK Link", sharedUrl))
                                    Toast.makeText(context, "Link copied to clipboard", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.OpenInBrowser, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Open Live App Link", fontSize = 12.sp)
                        }
                    }
                }

                // Option 3: Export APA Manuscript Report
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF8FAFC),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Article, contentDescription = null, tint = JamoviTeal, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("3. Export Full APA 7th Manuscript", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = JamoviTeal)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Button(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("APA Statistical Report", fullApaReportText))
                                Toast.makeText(context, "Full APA report copied to clipboard!", Toast.LENGTH_LONG).show()

                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, "Jamovi Statistical APA Report")
                                    putExtra(Intent.EXTRA_TEXT, fullApaReportText)
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share APA Report"))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = JamoviTeal),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share / Copy APA Report", fontSize = 12.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = JamoviTeal)
            ) {
                Text("Done")
            }
        }
    )
}
