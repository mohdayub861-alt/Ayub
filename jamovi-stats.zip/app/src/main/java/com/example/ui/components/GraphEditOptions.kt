package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.JamoviTeal
import com.example.ui.theme.JamoviTealContainer

enum class GraphColorTheme(val label: String, val primary: Color, val accent: Color) {
    JAMOVI_TEAL("Jamovi Teal", Color(0xFF0E7490), Color(0xFF22D3EE)),
    APA_GRAYSCALE("APA Grayscale", Color(0xFF334155), Color(0xFF64748B)),
    OCEAN_BLUE("Ocean Blue", Color(0xFF2563EB), Color(0xFF60A5FA)),
    SUNSET_CORAL("Sunset Coral", Color(0xFFE11D48), Color(0xFFFB7185)),
    EMERALD_GREEN("Emerald", Color(0xFF059669), Color(0xFF34D399))
}

data class GraphSettings(
    val theme: GraphColorTheme = GraphColorTheme.JAMOVI_TEAL,
    val showMean: Boolean = true,
    val showRawPoints: Boolean = true,
    val showNormalCurve: Boolean = true,
    val showCiBand: Boolean = true,
    val showGridlines: Boolean = true,
    val customTitle: String? = null,
    val customXLabel: String? = null,
    val customYLabel: String? = null
)

@Composable
fun GraphEditDialog(
    currentSettings: GraphSettings,
    onSave: (GraphSettings) -> Unit,
    onDismiss: () -> Unit
) {
    var theme by remember { mutableStateOf(currentSettings.theme) }
    var showMean by remember { mutableStateOf(currentSettings.showMean) }
    var showRawPoints by remember { mutableStateOf(currentSettings.showRawPoints) }
    var showNormalCurve by remember { mutableStateOf(currentSettings.showNormalCurve) }
    var showCiBand by remember { mutableStateOf(currentSettings.showCiBand) }
    var showGridlines by remember { mutableStateOf(currentSettings.showGridlines) }
    var customTitle by remember { mutableStateOf(currentSettings.customTitle ?: "") }
    var customXLabel by remember { mutableStateOf(currentSettings.customXLabel ?: "") }
    var customYLabel by remember { mutableStateOf(currentSettings.customYLabel ?: "") }

    val scrollState = rememberScrollState()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Tune, contentDescription = null, tint = JamoviTeal)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Graph & Plot Customization", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. Color Palette
                Text("Color Palette", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    GraphColorTheme.values().forEach { t ->
                        val isSel = theme == t
                        Surface(
                            onClick = { theme = t },
                            shape = CircleShape,
                            color = t.primary,
                            modifier = Modifier
                                .size(34.dp)
                                .then(
                                    if (isSel) Modifier.padding(2.dp) else Modifier
                                )
                        ) {
                            if (isSel) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.White.copy(alpha = 0.3f), CircleShape)
                                )
                            }
                        }
                    }
                }
                Text("Selected: ${theme.label}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                HorizontalDivider()

                // 2. Display Elements
                Text("Plot Elements", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showMean = !showMean }
                ) {
                    Checkbox(checked = showMean, onCheckedChange = { showMean = it })
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Show Mean Marker (Diamond)", fontSize = 13.sp)
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showRawPoints = !showRawPoints }
                ) {
                    Checkbox(checked = showRawPoints, onCheckedChange = { showRawPoints = it })
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Show Raw Data Points (Jitter)", fontSize = 13.sp)
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showNormalCurve = !showNormalCurve }
                ) {
                    Checkbox(checked = showNormalCurve, onCheckedChange = { showNormalCurve = it })
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Show Normal Density Curve", fontSize = 13.sp)
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showCiBand = !showCiBand }
                ) {
                    Checkbox(checked = showCiBand, onCheckedChange = { showCiBand = it })
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Show 95% Confidence Interval Band", fontSize = 13.sp)
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showGridlines = !showGridlines }
                ) {
                    Checkbox(checked = showGridlines, onCheckedChange = { showGridlines = it })
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Show Subtle Gridlines", fontSize = 13.sp)
                }

                HorizontalDivider()

                // 3. Titles and Labels
                Text("Titles & Axis Labels", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = customTitle,
                    onValueChange = { customTitle = it },
                    label = { Text("Custom Plot Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = customXLabel,
                    onValueChange = { customXLabel = it },
                    label = { Text("Custom X-Axis Label") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = customYLabel,
                    onValueChange = { customYLabel = it },
                    label = { Text("Custom Y-Axis Label") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        GraphSettings(
                            theme = theme,
                            showMean = showMean,
                            showRawPoints = showRawPoints,
                            showNormalCurve = showNormalCurve,
                            showCiBand = showCiBand,
                            showGridlines = showGridlines,
                            customTitle = customTitle.ifBlank { null },
                            customXLabel = customXLabel.ifBlank { null },
                            customYLabel = customYLabel.ifBlank { null }
                        )
                    )
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = JamoviTeal)
            ) {
                Text("Apply")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
