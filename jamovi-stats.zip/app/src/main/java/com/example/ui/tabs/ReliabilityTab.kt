package com.example.ui.tabs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.model.Dataset
import com.example.stats.StatsMath
import com.example.ui.components.*

@Composable
fun ReliabilityTab(
    dataset: Dataset,
    modifier: Modifier = Modifier
) {
    val continuousCols = dataset.continuousColumns()
    var selectedColIds by remember(dataset) {
        mutableStateOf(continuousCols.take(4).map { it.id }.toSet())
    }
    val selectedItems = continuousCols.filter { selectedColIds.contains(it.id) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    VariableChipRow(
                        title = "Select Scale Items for Reliability & Item Analysis:",
                        availableColumns = continuousCols,
                        selectedIds = selectedColIds,
                        onToggleColumn = { colId ->
                            selectedColIds = if (selectedColIds.contains(colId)) {
                                if (selectedColIds.size > 2) selectedColIds - colId else selectedColIds
                            } else {
                                selectedColIds + colId
                            }
                        }
                    )
                }
            }
        }

        if (selectedItems.size >= 2) {
            val itemsData = selectedItems.map { it.getValidDoubles() }
            val itemNames = selectedItems.map { it.name }
            val relResult = StatsMath.calculateReliability(itemsData, itemNames)

            item {
                // Table 7a: Overall Scale Reliability
                val summaryCols = listOf(
                    TableColumn("Scale", width = 110),
                    TableColumn("Items (k)", width = 80),
                    TableColumn("Cronbach's α", width = 100, isSymbol = true),
                    TableColumn("Std. α", width = 85, isSymbol = true),
                    TableColumn("McDonald's ω", width = 105, isSymbol = true),
                    TableColumn("Mean Inter-Item r", width = 120, isSymbol = true)
                )

                val summaryRows = listOf(
                    listOf(
                        "Total Scale",
                        relResult.nItems.toString(),
                        StatsMath.formatNumber(relResult.cronbachAlpha),
                        StatsMath.formatNumber(relResult.standardizedAlpha),
                        StatsMath.formatNumber(relResult.mcdonaldOmega),
                        StatsMath.formatNumber(relResult.avgInterItemCorrel)
                    )
                )

                val narrative = "Internal consistency reliability for the ${relResult.nItems}-item scale was examined in N = ${relResult.nCases} participants. The scale exhibited strong reliability with Cronbach's α = ${StatsMath.formatNumber(relResult.cronbachAlpha)} and McDonald's ω = ${StatsMath.formatNumber(relResult.mcdonaldOmega)}. The average inter-item correlation was r = ${StatsMath.formatNumber(relResult.avgInterItemCorrel)}."

                ApaTable(
                    tableNumber = "Table 7a",
                    tableTitle = "Scale Reliability Indices and Internal Consistency",
                    columns = summaryCols,
                    rows = summaryRows,
                    note = "k = number of scale items; α = Cronbach's alpha; ω = McDonald's omega coefficient; r = Pearson correlation coefficient.",
                    inTextReport = narrative
                )
            }

            item {
                // Table 7b: Item-Rest Statistics & Alpha If Deleted
                val itemCols = listOf(
                    TableColumn("Item", width = 130),
                    TableColumn("M", width = 65, isSymbol = true),
                    TableColumn("SD", width = 65, isSymbol = true),
                    TableColumn("Item-Rest r", width = 100, isSymbol = true),
                    TableColumn("α if Deleted", width = 105, isSymbol = true)
                )

                val itemRows = relResult.items.map { itm ->
                    listOf(
                        itm.itemName,
                        StatsMath.formatNumber(itm.mean),
                        StatsMath.formatNumber(itm.sd),
                        StatsMath.formatNumber(itm.itemRestCorrel),
                        StatsMath.formatNumber(itm.alphaIfDeleted)
                    )
                }

                ApaTable(
                    tableNumber = "Table 7b",
                    tableTitle = "Item-Total Statistics and Cronbach's Alpha if Item Deleted",
                    columns = itemCols,
                    rows = itemRows,
                    note = "Item-rest r represents the corrected item-total correlation."
                )
            }

            item {
                val groupMap = selectedItems.associate { it.name to it.getValidDoubles() }
                BoxPlotWithJitter(
                    groups = groupMap,
                    title = "Figure 6. Item Score Distributions Across Scale Measures"
                )
            }
        }
    }
}
