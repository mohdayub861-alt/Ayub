package com.example.ui.tabs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.model.Dataset
import com.example.stats.StatsMath
import com.example.ui.components.*

@Composable
fun CorrelationTab(
    dataset: Dataset,
    modifier: Modifier = Modifier
) {
    var method by remember { mutableStateOf("Pearson") } // "Pearson", "Spearman", "Partial"
    val continuousCols = dataset.continuousColumns()

    var selectedColIds by remember(dataset) {
        mutableStateOf(continuousCols.take(4).map { it.id }.toSet())
    }
    val selectedCols = continuousCols.filter { selectedColIds.contains(it.id) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Pearson", "Spearman", "Partial").forEach { m ->
                            FilterChip(
                                selected = method == m,
                                onClick = { method = m },
                                label = { Text("$m r") }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    VariableChipRow(
                        title = "Select Variables for Correlation Matrix:",
                        availableColumns = continuousCols,
                        selectedIds = selectedColIds,
                        onToggleColumn = { colId ->
                            selectedColIds = if (selectedColIds.contains(colId)) {
                                if (selectedColIds.size > 2) selectedColIds - colId else selectedColIds
                            } else {
                                selectedColIds + colId
                            }
                        }
                    )
                }
            }
        }

        if (selectedCols.size >= 2) {
            item {
                val p = selectedCols.size
                val matrix = Array(p) { i ->
                    Array(p) { j ->
                        val x = selectedCols[i].getValidDoubles()
                        val y = selectedCols[j].getValidDoubles()
                        if (method == "Spearman") StatsMath.spearman(x, y) else StatsMath.pearson(x, y)
                    }
                }

                val tableCols = mutableListOf<TableColumn>()
                tableCols.add(TableColumn("Variable", width = 130))
                tableCols.add(TableColumn("M", width = 65, isSymbol = true))
                tableCols.add(TableColumn("SD", width = 65, isSymbol = true))
                for (j in 0 until p) {
                    tableCols.add(TableColumn("${j + 1}", width = 65))
                }

                val rows = mutableListOf<List<String>>()
                for (i in 0 until p) {
                    val rowData = mutableListOf<String>()
                    val varCol = selectedCols[i]
                    val vals = varCol.getValidDoubles()
                    rowData.add("${i + 1}. ${varCol.name}")
                    rowData.add(StatsMath.formatNumber(StatsMath.mean(vals)))
                    rowData.add(StatsMath.formatNumber(StatsMath.sd(vals)))

                    for (j in 0 until p) {
                        if (j < i) {
                            val rVal = matrix[i][j].r
                            val pVal = matrix[i][j].p
                            val stars = when {
                                pVal < 0.001 -> "***"
                                pVal < 0.01 -> "**"
                                pVal < 0.05 -> "*"
                                else -> ""
                            }
                            val formattedR = StatsMath.formatNumber(rVal)
                            val cleanR = if (formattedR.startsWith("0.")) formattedR.substring(1) else if (formattedR.startsWith("-0.")) "-." + formattedR.substring(3) else formattedR
                            rowData.add("$cleanR$stars")
                        } else if (j == i) {
                            rowData.add("—")
                        } else {
                            rowData.add("")
                        }
                    }
                    rows.add(rowData)
                }

                val r12 = matrix[1][0]
                val narrative = "A ${method.lowercase()} correlation analysis indicated a significant relationship between ${selectedCols[0].name} and ${selectedCols[1].name}, r(${r12.n - 2}) = ${StatsMath.formatNumber(r12.r)}, p ${StatsMath.formatPValue(r12.p)}, 95% CI [${StatsMath.formatNumber(r12.ciL)}, ${StatsMath.formatNumber(r12.ciU)}]."

                ApaTable(
                    tableNumber = "Table 5",
                    tableTitle = "Intercorrelations, Means, and Standard Deviations for Study Variables",
                    columns = tableCols,
                    rows = rows,
                    note = "N = ${matrix[0][0].n}. *p < .05. **p < .01. ***p < .001 (two-tailed). Diagonal entries are dashed; values below diagonal represent bivariate correlation coefficients.",
                    inTextReport = narrative
                )
            }

            // Scatterplot for first two variables
            item {
                val xCol = selectedCols[0]
                val yCol = selectedCols[1]
                RegressionScatterPlot(
                    x = xCol.getValidDoubles(),
                    y = yCol.getValidDoubles(),
                    xLabel = xCol.name,
                    yLabel = yCol.name
                )
            }
        }
    }
}
