package com.example.ui.tabs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.model.Dataset
import com.example.stats.StatsMath
import com.example.ui.components.*

@Composable
fun TTestsTab(
    dataset: Dataset,
    modifier: Modifier = Modifier
) {
    var testType by remember { mutableStateOf("Independent") } // "Independent", "Paired", "One-Sample"
    val continuousCols = dataset.continuousColumns()
    val categoricalCols = dataset.categoricalColumns()

    var selectedDvId by remember(dataset) {
        mutableStateOf(continuousCols.firstOrNull()?.id)
    }
    var selectedFactorId by remember(dataset) {
        mutableStateOf(categoricalCols.firstOrNull()?.id)
    }
    var selectedPairPreId by remember(dataset) {
        mutableStateOf(continuousCols.getOrNull(0)?.id)
    }
    var selectedPairPostId by remember(dataset) {
        mutableStateOf(continuousCols.getOrNull(1)?.id)
    }
    var testValueInput by remember { mutableStateOf("70.0") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Independent", "Paired", "One-Sample").forEach { type ->
                            FilterChip(
                                selected = testType == type,
                                onClick = { testType = type },
                                label = { Text("$type t-Test") }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    when (testType) {
                        "Independent" -> {
                            SingleVariableSelector(
                                title = "Dependent Variable (Continuous):",
                                availableColumns = continuousCols,
                                selectedId = selectedDvId,
                                onSelectColumn = { selectedDvId = it }
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            SingleVariableSelector(
                                title = "Grouping Variable (Nominal / Ordinal):",
                                availableColumns = categoricalCols.ifEmpty { continuousCols },
                                selectedId = selectedFactorId,
                                onSelectColumn = { selectedFactorId = it }
                            )
                        }
                        "Paired" -> {
                            SingleVariableSelector(
                                title = "Measure 1 (Pre-test):",
                                availableColumns = continuousCols,
                                selectedId = selectedPairPreId,
                                onSelectColumn = { selectedPairPreId = it }
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            SingleVariableSelector(
                                title = "Measure 2 (Post-test):",
                                availableColumns = continuousCols,
                                selectedId = selectedPairPostId,
                                onSelectColumn = { selectedPairPostId = it }
                            )
                        }
                        "One-Sample" -> {
                            SingleVariableSelector(
                                title = "Test Variable:",
                                availableColumns = continuousCols,
                                selectedId = selectedDvId,
                                onSelectColumn = { selectedDvId = it }
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = testValueInput,
                                onValueChange = { testValueInput = it },
                                label = { Text("Hypothesized Mean (μ₀)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(0.5f)
                            )
                        }
                    }
                }
            }
        }

        // Calculation & APA Output
        item {
            when (testType) {
                "Independent" -> {
                    val dvCol = dataset.columns.find { it.id == selectedDvId }
                    val factorCol = dataset.columns.find { it.id == selectedFactorId }
                    if (dvCol != null && factorCol != null) {
                        val grouped = mutableMapOf<String, MutableList<Double>>()
                        val n = minOf(dvCol.values.size, factorCol.values.size)
                        for (i in 0 until n) {
                            val v = dvCol.values[i].toDoubleOrNull()
                            val g = factorCol.values[i].trim()
                            if (v != null && g.isNotEmpty()) {
                                grouped.getOrPut(g) { mutableListOf() }.add(v)
                            }
                        }

                        val groupKeys = grouped.keys.toList()
                        if (groupKeys.size >= 2) {
                            val g1 = grouped[groupKeys[0]]!!
                            val g2 = grouped[groupKeys[1]]!!
                            val result = StatsMath.independentTTest(g1, g2, groupKeys[0], groupKeys[1])

                            val narrative = "An independent-samples t-test was conducted to compare ${dvCol.name} between ${groupKeys[0]} and ${groupKeys[1]}. There was a statistically significant difference: ${groupKeys[0]} (M = ${StatsMath.formatNumber(result.group1Mean)}, SD = ${StatsMath.formatNumber(result.group1SD)}) scored differently than ${groupKeys[1]} (M = ${StatsMath.formatNumber(result.group2Mean)}, SD = ${StatsMath.formatNumber(result.group2SD)}), t(${StatsMath.formatNumber(result.df, 0)}) = ${StatsMath.formatNumber(result.tStat)}, p ${StatsMath.formatPValue(result.pValue)}, d = ${StatsMath.formatNumber(result.cohenD)}, 95% CI [${StatsMath.formatNumber(result.ciLower)}, ${StatsMath.formatNumber(result.ciUpper)}]."

                            val columns = listOf(
                                TableColumn("Comparison", width = 120),
                                TableColumn("Statistic", width = 75, isSymbol = true),
                                TableColumn("df", width = 50, isSymbol = true),
                                TableColumn("p", width = 70, isSymbol = true),
                                TableColumn("Mean Diff", width = 85),
                                TableColumn("SE Diff", width = 75),
                                TableColumn("Cohen's d", width = 80, isSymbol = true),
                                TableColumn("95% CI Lower", width = 95),
                                TableColumn("95% CI Upper", width = 95),
                                TableColumn("Levene's F", width = 85),
                                TableColumn("Levene's p", width = 85)
                            )

                            val rows = listOf(
                                listOf(
                                    "${groupKeys[0]} vs ${groupKeys[1]}",
                                    StatsMath.formatNumber(result.tStat),
                                    StatsMath.formatNumber(result.df, 0),
                                    StatsMath.formatPValue(result.pValue),
                                    StatsMath.formatNumber(result.meanDifference),
                                    StatsMath.formatNumber(result.seDiff),
                                    StatsMath.formatNumber(result.cohenD),
                                    StatsMath.formatNumber(result.ciLower),
                                    StatsMath.formatNumber(result.ciUpper),
                                    StatsMath.formatNumber(result.leveneF),
                                    StatsMath.formatPValue(result.leveneP)
                                )
                            )

                            ApaTable(
                                tableNumber = "Table 2",
                                tableTitle = "Independent Samples t-Test Comparing ${dvCol.name} by ${factorCol.name}",
                                columns = columns,
                                rows = rows,
                                note = "Student's two-tailed test with pooled variance. Levene's test for equality of error variances: p > .05 confirms homogeneity of variance assumption.",
                                inTextReport = narrative
                            )

                            Spacer(modifier = Modifier.height(16.dp))
                            BoxPlotWithJitter(
                                groups = mapOf(groupKeys[0] to g1, groupKeys[1] to g2),
                                title = "Figure 3. Group Distribution for ${dvCol.name} by ${factorCol.name}"
                            )
                        } else {
                            Text("The selected grouping variable must contain at least 2 distinct levels.")
                        }
                    }
                }
                "Paired" -> {
                    val preCol = dataset.columns.find { it.id == selectedPairPreId }
                    val postCol = dataset.columns.find { it.id == selectedPairPostId }
                    if (preCol != null && postCol != null) {
                        val preVals = preCol.getValidDoubles()
                        val postVals = postCol.getValidDoubles()
                        val result = StatsMath.pairedTTest(preVals, postVals, preCol.name, postCol.name)

                        val narrative = "A paired-samples t-test indicated that scores significantly improved from ${preCol.name} (M = ${StatsMath.formatNumber(result.group1Mean)}, SD = ${StatsMath.formatNumber(result.group1SD)}) to ${postCol.name} (M = ${StatsMath.formatNumber(result.group2Mean)}, SD = ${StatsMath.formatNumber(result.group2SD)}), t(${StatsMath.formatNumber(result.df, 0)}) = ${StatsMath.formatNumber(result.tStat)}, p ${StatsMath.formatPValue(result.pValue)}, Cohen's d = ${StatsMath.formatNumber(result.cohenD)}, 95% CI [${StatsMath.formatNumber(result.ciLower)}, ${StatsMath.formatNumber(result.ciUpper)}]."

                        val columns = listOf(
                            TableColumn("Pair", width = 130),
                            TableColumn("t", width = 70, isSymbol = true),
                            TableColumn("df", width = 50, isSymbol = true),
                            TableColumn("p", width = 70, isSymbol = true),
                            TableColumn("Mean Diff", width = 85),
                            TableColumn("SE Diff", width = 75),
                            TableColumn("Cohen's d", width = 80, isSymbol = true),
                            TableColumn("95% CI Lower", width = 95),
                            TableColumn("95% CI Upper", width = 95)
                        )

                        val rows = listOf(
                            listOf(
                                "${postCol.name} - ${preCol.name}",
                                StatsMath.formatNumber(result.tStat),
                                StatsMath.formatNumber(result.df, 0),
                                StatsMath.formatPValue(result.pValue),
                                StatsMath.formatNumber(result.meanDifference),
                                StatsMath.formatNumber(result.seDiff),
                                StatsMath.formatNumber(result.cohenD),
                                StatsMath.formatNumber(result.ciLower),
                                StatsMath.formatNumber(result.ciUpper)
                            )
                        )

                        ApaTable(
                            tableNumber = "Table 2",
                            tableTitle = "Paired Samples t-Test for ${preCol.name} and ${postCol.name}",
                            columns = columns,
                            rows = rows,
                            note = "Paired differences calculated as Post-Test minus Pre-Test.",
                            inTextReport = narrative
                        )

                        Spacer(modifier = Modifier.height(16.dp))
                        BoxPlotWithJitter(
                            groups = mapOf(preCol.name to preVals, postCol.name to postVals),
                            title = "Figure 3. Within-Subjects Comparison of ${preCol.name} and ${postCol.name}"
                        )
                    }
                }
                "One-Sample" -> {
                    val dvCol = dataset.columns.find { it.id == selectedDvId }
                    val mu0 = testValueInput.toDoubleOrNull() ?: 70.0
                    if (dvCol != null) {
                        val vals = dvCol.getValidDoubles()
                        val result = StatsMath.oneSampleTTest(vals, mu0, dvCol.name)

                        val narrative = "A one-sample t-test was conducted comparing sample ${dvCol.name} (M = ${StatsMath.formatNumber(result.group1Mean)}, SD = ${StatsMath.formatNumber(result.group1SD)}) against hypothesized benchmark μ₀ = $mu0, demonstrating a significant difference: t(${StatsMath.formatNumber(result.df, 0)}) = ${StatsMath.formatNumber(result.tStat)}, p ${StatsMath.formatPValue(result.pValue)}, d = ${StatsMath.formatNumber(result.cohenD)}."

                        val columns = listOf(
                            TableColumn("Variable", width = 110),
                            TableColumn("Test Value", width = 85),
                            TableColumn("t", width = 70, isSymbol = true),
                            TableColumn("df", width = 50, isSymbol = true),
                            TableColumn("p", width = 70, isSymbol = true),
                            TableColumn("Mean Diff", width = 85),
                            TableColumn("Cohen's d", width = 80, isSymbol = true),
                            TableColumn("95% CI Lower", width = 95),
                            TableColumn("95% CI Upper", width = 95)
                        )

                        val rows = listOf(
                            listOf(
                                dvCol.name,
                                mu0.toString(),
                                StatsMath.formatNumber(result.tStat),
                                StatsMath.formatNumber(result.df, 0),
                                StatsMath.formatPValue(result.pValue),
                                StatsMath.formatNumber(result.meanDifference),
                                StatsMath.formatNumber(result.cohenD),
                                StatsMath.formatNumber(result.ciLower),
                                StatsMath.formatNumber(result.ciUpper)
                            )
                        )

                        ApaTable(
                            tableNumber = "Table 2",
                            tableTitle = "One-Sample t-Test for ${dvCol.name}",
                            columns = columns,
                            rows = rows,
                            note = "Test value = $mu0.",
                            inTextReport = narrative
                        )

                        Spacer(modifier = Modifier.height(16.dp))
                        DensityHistogramPlot(
                            data = vals,
                            title = "Figure 3. Sample Mean Relative to Benchmark $mu0"
                        )
                    }
                }
            }
        }
    }
}
