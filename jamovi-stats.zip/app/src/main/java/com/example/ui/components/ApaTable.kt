package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.JamoviTeal
import kotlin.math.max

data class TableColumn(
    val title: String,
    val width: Int = 100, // dp width
    val isSymbol: Boolean = false // whether to italicize heading
)

@Composable
fun ApaTable(
    tableNumber: String,
    tableTitle: String,
    columns: List<TableColumn>,
    rows: List<List<String>>,
    note: String? = null,
    inTextReport: String? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    val isDark = isSystemInDarkTheme()

    // High-contrast, theme-safe semantic colors
    val cardBackground = if (isDark) Color(0xFF1E293B) else Color.White
    val titleColor = if (isDark) Color(0xFFF8FAFC) else Color(0xFF0F172A)
    val headerBg = if (isDark) Color(0xFF0F172A) else Color(0xFFF1F5F9)
    val headerTextColor = if (isDark) Color(0xFFF8FAFC) else Color(0xFF0F172A)
    val rowBgEven = if (isDark) Color(0xFF1E293B) else Color.White
    val rowBgOdd = if (isDark) Color(0xFF243044) else Color(0xFFF8FAFC)
    val cellTextColor = if (isDark) Color(0xFFF8FAFC) else Color(0xFF0F172A)
    val ruleColor = if (isDark) Color(0xFF94A3B8) else Color(0xFF0F172A)
    val subtleRuleColor = if (isDark) Color(0xFF475569) else Color(0xFFCBD5E1)
    val noteColor = if (isDark) Color(0xFF94A3B8) else Color(0xFF475569)

    val effectiveColWidths = remember(columns) {
        columns.map { maxOf(it.width, 70).dp }
    }
    val totalTableWidth = remember(effectiveColWidths) {
        effectiveColWidths.fold(0.dp) { acc: Dp, w: Dp -> acc + w }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = cardBackground),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header: Table Number & Title & Action buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = tableNumber,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = titleColor
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = tableTitle,
                        fontStyle = FontStyle.Italic,
                        fontSize = 14.sp,
                        color = titleColor
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    // Copy APA formatted table
                    IconButton(
                        onClick = {
                            val tsv = buildString {
                                appendLine("$tableNumber\n$tableTitle")
                                appendLine(columns.joinToString("\t") { it.title })
                                rows.forEach { row ->
                                    appendLine(row.joinToString("\t"))
                                }
                                if (note != null) appendLine("Note. $note")
                            }
                            copyToClipboard(context, "APA Table", tsv)
                            Toast.makeText(context, "APA Table copied to clipboard", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            Icons.Default.ContentCopy,
                            contentDescription = "Copy APA Table",
                            tint = JamoviTeal,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Copy APA In-Text Narrative Summary
                    if (inTextReport != null) {
                        IconButton(
                            onClick = {
                                copyToClipboard(context, "APA In-Text Report", inTextReport)
                                Toast.makeText(context, "APA In-Text Summary copied", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                Icons.Default.Description,
                                contentDescription = "Copy In-Text Summary",
                                tint = JamoviTeal,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Horizontally scrollable APA Table Block
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(scrollState)
            ) {
                Column(modifier = Modifier.width(totalTableWidth)) {
                    // 1. APA Top Rule (bold line, 2dp)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(2.dp)
                            .background(ruleColor)
                    )

                    // Header Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(headerBg)
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        columns.forEachIndexed { index, col ->
                            val colW = effectiveColWidths.getOrElse(index) { col.width.dp }
                            Box(
                                modifier = Modifier
                                    .width(colW)
                                    .padding(horizontal = 6.dp),
                                contentAlignment = if (index == 0) Alignment.CenterStart else Alignment.CenterEnd
                            ) {
                                Text(
                                    text = col.title,
                                    fontSize = 13.sp,
                                    fontStyle = if (col.isSymbol) FontStyle.Italic else FontStyle.Normal,
                                    fontWeight = FontWeight.Bold,
                                    color = headerTextColor,
                                    textAlign = if (index == 0) TextAlign.Start else TextAlign.End,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    // 2. APA Header Bottom Rule (1dp)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(subtleRuleColor)
                    )

                    // Data Rows with alternating theme-aware background and guaranteed contrasting text
                    if (rows.isEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(rowBgEven)
                                .padding(vertical = 12.dp, horizontal = 12.dp),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "No values to display",
                                fontSize = 13.sp,
                                color = cellTextColor.copy(alpha = 0.6f),
                                fontStyle = FontStyle.Italic
                            )
                        }
                    } else {
                        rows.forEachIndexed { rowIndex, rowData ->
                            val currentBg = if (rowIndex % 2 == 1) rowBgOdd else rowBgEven
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(currentBg)
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                columns.forEachIndexed { colIndex, col ->
                                    val colW = effectiveColWidths.getOrElse(colIndex) { col.width.dp }
                                    val cellText = rowData.getOrElse(colIndex) { "—" }
                                    Box(
                                        modifier = Modifier
                                            .width(colW)
                                            .padding(horizontal = 6.dp),
                                        contentAlignment = if (colIndex == 0) Alignment.CenterStart else Alignment.CenterEnd
                                    ) {
                                        Text(
                                            text = cellText,
                                            fontSize = 13.sp,
                                            fontWeight = if (colIndex == 0) FontWeight.Medium else FontWeight.Normal,
                                            color = cellTextColor,
                                            textAlign = if (colIndex == 0) TextAlign.Start else TextAlign.End,
                                            maxLines = 3,
                                            softWrap = true,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 3. APA Bottom Table Rule (1.5dp)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.5.dp)
                            .background(ruleColor)
                    )
                }
            }

            // APA Note
            if (note != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Note. ",
                        fontStyle = FontStyle.Italic,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.5.sp,
                        color = noteColor
                    )
                    Text(
                        text = note,
                        fontSize = 11.5.sp,
                        color = noteColor
                    )
                }
            }

            // In-text summary card preview
            if (inTextReport != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = MaterialTheme.shapes.small,
                    color = JamoviTeal.copy(alpha = if (isDark) 0.15f else 0.08f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "APA In-Text Reporting Format",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = JamoviTeal
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = inTextReport,
                            fontSize = 12.sp,
                            color = cellTextColor
                        )
                    }
                }
            }
        }
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText(label, text)
    clipboard.setPrimaryClip(clip)
}
