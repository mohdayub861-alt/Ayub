package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = LuxuryGreenLight,
    onPrimary = Color(0xFF072115),
    primaryContainer = LuxuryDarkGreen,
    onPrimaryContainer = LuxuryGreenContainer,
    secondary = LuxuryForestGreen,
    onSecondary = Color.White,
    background = Color(0xFF101713),
    surface = Color(0xFF17241C),
    onBackground = Color(0xFFF2F7F4),
    onSurface = Color(0xFFF2F7F4),
    surfaceVariant = Color(0xFF23362A),
    onSurfaceVariant = Color(0xFFC4D5CB)
)

private val LightColorScheme = lightColorScheme(
    primary = LuxuryDarkGreen,
    onPrimary = Color.White,
    primaryContainer = LuxuryGreenContainer,
    onPrimaryContainer = LuxuryOnGreenContainer,
    secondary = LuxuryForestGreen,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF0F7F3),
    onSecondaryContainer = LuxuryDarkGreen,
    tertiary = LuxuryGoldAccent,
    background = Color(0xFFFFFFFF), // Pure White Canvas
    surface = Color(0xFFFFFFFF),    // Pure White Surface
    onBackground = Color(0xFF14221A), // Crisp rich text
    onSurface = Color(0xFF14221A),
    surfaceVariant = Color(0xFFF4F8F5),
    onSurfaceVariant = Color(0xFF43534B),
    outline = Color(0xFFD8E4DC),
    outlineVariant = Color(0xFFE8EFEA)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
