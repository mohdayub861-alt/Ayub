package com.example.util

import android.content.Context
import android.net.Uri
import com.example.model.DataColumn
import com.example.model.Dataset
import com.example.model.VariableType
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

import android.provider.OpenableColumns
import java.io.BufferedInputStream

object SpreadsheetImporter {

    fun importFile(context: Context, uri: Uri): Dataset? {
        var resolvedName = "dataset.xlsx"
        try {
            val cursor = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val nameIdx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIdx >= 0) {
                        resolvedName = it.getString(nameIdx) ?: resolvedName
                    }
                }
            }
        } catch (_: Exception) {}

        return try {
            val rawStream = context.contentResolver.openInputStream(uri) ?: return null
            val bufferedStream = BufferedInputStream(rawStream)
            bufferedStream.mark(8)
            val headerBytes = ByteArray(4)
            val readCount = bufferedStream.read(headerBytes)
            bufferedStream.reset()

            // Check if it's a Zip container (XLSX files are zip archives starting with 'PK' 0x50, 0x4B)
            val isZipArchive = readCount >= 2 && headerBytes[0] == 0x50.toByte() && headerBytes[1] == 0x4B.toByte()
            val isXlsx = isZipArchive || resolvedName.lowercase().endsWith(".xlsx")

            if (isXlsx) {
                parseXlsx(bufferedStream, resolvedName)
            } else {
                parseCsv(bufferedStream, resolvedName)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun parseCsv(inputStream: InputStream, title: String): Dataset {
        val reader = BufferedReader(InputStreamReader(inputStream))
        val rows = mutableListOf<List<String>>()
        var line: String?

        while (reader.readLine().also { line = it } != null) {
            val trimmed = line?.trim() ?: continue
            if (trimmed.isEmpty()) continue
            // Parse comma-separated with basic quote handling
            val tokens = parseCsvLine(trimmed)
            if (tokens.isNotEmpty()) {
                rows.add(tokens)
            }
        }
        reader.close()

        return createDatasetFromRows(rows, title)
    }

    private fun parseCsvLine(line: String): List<String> {
        val tokens = mutableListOf<String>()
        val sb = StringBuilder()
        var inQuotes = false
        val delimiter = if (line.contains("\t") && !line.contains(",")) '\t' else ','

        for (ch in line) {
            if (ch == '\"') {
                inQuotes = !inQuotes
            } else if (ch == delimiter && !inQuotes) {
                tokens.add(sb.toString().trim())
                sb.clear()
            } else {
                sb.append(ch)
            }
        }
        tokens.add(sb.toString().trim())
        return tokens
    }

    fun parseXlsx(inputStream: InputStream, title: String): Dataset {
        val sharedStrings = mutableListOf<String>()
        val sheetRows = mutableListOf<MutableList<String>>()
        val zip = ZipInputStream(inputStream)
        var entry: ZipEntry?

        var sharedStringsBytes: ByteArray? = null
        var sheetBytes: ByteArray? = null

        while (zip.nextEntry.also { entry = it } != null) {
            val name = entry?.name ?: ""
            if (name.contains("sharedStrings.xml")) {
                sharedStringsBytes = zip.readBytes()
            } else if (name.contains("worksheets/sheet1.xml") || (name.contains("sheet") && name.endsWith(".xml") && sheetBytes == null)) {
                sheetBytes = zip.readBytes()
            }
            zip.closeEntry()
        }
        zip.close()

        // 1. Parse shared strings if present
        if (sharedStringsBytes != null) {
            val factory = XmlPullParserFactory.newInstance()
            val parser = factory.newPullParser()
            parser.setInput(sharedStringsBytes.inputStream(), "UTF-8")
            var eventType = parser.eventType
            var currentText = StringBuilder()
            var insideText = false

            while (eventType != XmlPullParser.END_DOCUMENT) {
                when (eventType) {
                    XmlPullParser.START_TAG -> {
                        if (parser.name == "t") {
                            insideText = true
                            currentText.clear()
                        }
                    }
                    XmlPullParser.TEXT -> {
                        if (insideText) {
                            currentText.append(parser.text)
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        if (parser.name == "t") {
                            insideText = false
                            sharedStrings.add(currentText.toString())
                        }
                    }
                }
                eventType = parser.next()
            }
        }

        // 2. Parse sheet1.xml
        if (sheetBytes != null) {
            val factory = XmlPullParserFactory.newInstance()
            val parser = factory.newPullParser()
            parser.setInput(sheetBytes.inputStream(), "UTF-8")
            var eventType = parser.eventType
            var currentRow: MutableList<String>? = null
            var cellType = ""
            var currentVal = StringBuilder()
            var insideVal = false

            while (eventType != XmlPullParser.END_DOCUMENT) {
                when (eventType) {
                    XmlPullParser.START_TAG -> {
                        when (parser.name) {
                            "row" -> {
                                currentRow = mutableListOf()
                            }
                            "c" -> {
                                cellType = parser.getAttributeValue(null, "t") ?: ""
                            }
                            "v" -> {
                                insideVal = true
                                currentVal.clear()
                            }
                        }
                    }
                    XmlPullParser.TEXT -> {
                        if (insideVal) {
                            currentVal.append(parser.text)
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        when (parser.name) {
                            "v" -> {
                                insideVal = false
                                val rawStr = currentVal.toString().trim()
                                val resolved = if (cellType == "s") {
                                    val idx = rawStr.toIntOrNull() ?: -1
                                    if (idx in sharedStrings.indices) sharedStrings[idx] else rawStr
                                } else {
                                    rawStr
                                }
                                currentRow?.add(resolved)
                            }
                            "row" -> {
                                currentRow?.let {
                                    if (it.isNotEmpty()) sheetRows.add(it)
                                }
                                currentRow = null
                            }
                        }
                    }
                }
                eventType = parser.next()
            }
        }

        return createDatasetFromRows(sheetRows, title)
    }

    private fun createDatasetFromRows(rows: List<List<String>>, title: String): Dataset {
        if (rows.isEmpty()) {
            return Dataset(
                id = "empty_${System.currentTimeMillis()}",
                title = title.replace(".xlsx", "").replace(".csv", ""),
                description = "Empty dataset imported",
                columns = emptyList()
            )
        }

        val headerRow = rows[0]
        val dataRows = rows.drop(1)
        val numCols = headerRow.size

        val columns = headerRow.mapIndexed { colIdx, colName ->
            val colValues = dataRows.map { row ->
                row.getOrElse(colIdx) { "" }.trim()
            }
            // Auto detect type
            val nonBlank = colValues.filter { it.isNotEmpty() }
            val numericCount = nonBlank.count { it.toDoubleOrNull() != null }
            val isNumeric = nonBlank.isNotEmpty() && (numericCount.toDouble() / nonBlank.size >= 0.8)

            val vType = if (isNumeric) {
                VariableType.SCALE
            } else {
                val distinctCount = nonBlank.distinct().size
                if (distinctCount in 2..7) VariableType.NOMINAL else VariableType.NOMINAL
            }

            DataColumn(
                id = "col_${colIdx}_${System.currentTimeMillis()}",
                name = if (colName.isNotBlank()) colName else "Var_${colIdx + 1}",
                type = vType,
                values = colValues
            )
        }

        return Dataset(
            id = "imported_${System.currentTimeMillis()}",
            title = title.replace(".xlsx", "").replace(".csv", "").replace("_", " ").capitalize(),
            description = "Imported dataset with ${dataRows.size} rows and ${columns.size} variables.",
            columns = columns
        )
    }
}
